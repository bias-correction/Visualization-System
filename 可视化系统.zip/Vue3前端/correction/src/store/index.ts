import { defineStore } from 'pinia'

export const Store = defineStore('index', {
  // 为了完整类型推理，推荐使用箭头函数
  state: () => {
    return {
      date:'',
      step:'',
      is_loading: false,
      src_data:'',
      src_correct:'',
      src_truth:'',
      intro:{'U-Net':'U-Net是为了解决生物医学图像分割问题而产生的。因为它的效果很好，所以后来被广泛应用于语义分割的各个方向：比如卫星图像分割等等。如今，一些学者也将U-Net应用于气象要素的订正中，起到了很好的效果。',
      'UNet 3+':'UNet 3+在U-Net的基础上利用了全尺度的跳跃连接(skip connection)，全尺度的跳跃连接把来自不同尺度特征图中的高级语义与低级语义结合，提升了订正效果。',
      'S-CUnet 3+':'S-CUnet 3+是一个基于U-Net、Swin Transformer和多尺度连接提出的一个新的模型，S-CUnet 3+保留了U-Net的U型结构，由编码器、中间部分和解码器3个部分组成。S-CUnet 3+模型的结构如下图所示。'},
      model_img:{
        'U-Net':new URL('../assets/models/U-Net.png', import.meta.url).href,
        'UNet 3+':new URL('../assets/models/UNet 3+.png', import.meta.url).href,
        'S-CUnet 3+':new URL('../assets/models/S-CUnet 3+.png', import.meta.url).href
      },
      disabled:false,
      user_data:[],
      tables: {'user': '用户表', 'dataset': '数据集表'},
      selected_table: ''
    }
  },
  getters: {
    model_getter(state){
        var m = []
        for(let key in state.models){
            m.push(key)
        }
          return m
    },
    mod_getter(state){
        return state.model
    }
  },
  actions:{
    getImg(choices: any[]){
        this.date = choices[0]
        this.step = choices[1]
        this.src_data = choices[2]
        this.src_correct = choices[3]
        this.src_truth = choices[4]
    },
    set_disable(index: number){
        if (index == 0){
            this.disabled = false
        }
        else{
            this.disabled = true
        }
    }
  }
})
