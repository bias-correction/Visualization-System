<template>
<h5 id="sel-table">{{ sel_table }}</h5>

<el-form
:model="ruleForm"
class="demo-form-inline"
:inline="true"
>
<el-form-item label="机构" prop="origin">
    <el-input v-model="ruleForm.origin" autocomplete="off" />
</el-form-item>
<el-form-item label="日期" prop="date">
    <el-date-picker
        v-model="ruleForm.date"
        type="date"
        placeholder="选择年月"
        :disabled-date="pickerOptions"
        :default-value="defaultTime()"
        @change="dateChange()">
    </el-date-picker>
</el-form-item>
<el-form-item label="预报步长" prop="step">
    <el-select
        v-model="ruleForm.step"
        placeholder="请选择步长"
        clearable
        @change="stepChange()"
    >
        <el-option label="0-24" value="0-24" />
        <el-option label="24-48" value="24-48" />
        <el-option label="48-72" value="48-72" />
        <el-option label="72-96" value="72-96" />
        <el-option label="96-120" value="96-120" />
        <el-option label="120-144" value="120-144" />
        <el-option label="144-168" value="144-168" />
    </el-select>
</el-form-item>
<el-form-item label="类型" prop="type">
    <el-select
        v-model="ruleForm.type"
        placeholder="请选择类型"
        clearable
        @change="typeChange()"
      >
        <el-option label="原预报数据" value="data" />
        <el-option label="订正结果" value="pred" />
        <el-option label="标签数据" value="label" />
      </el-select>
</el-form-item>
<el-form-item>
    <el-button type="primary" @click="query()" :icon="Search">查询</el-button>
</el-form-item>
</el-form>

<el-table style="width: 100%" :data="data_list">
    <el-table-column label="序号">
        <template #default="scope">
            <div>
                <span>{{ scope.row.id }}</span>
            </div>
        </template>
    </el-table-column>
    <el-table-column label="机构名">
        <template #default="scope">
            <div>
                <span>{{ scope.row.origin }}</span>
            </div>
        </template>
    </el-table-column>
    <el-table-column label="日期">
        <template #default="scope">
            <div>
                <span>{{ new Date(scope.row.date).toLocaleDateString('zh-CN') }}</span>
            </div>
        </template>
    </el-table-column>
    <el-table-column label="预报步长">
        <template #default="scope">
            <div>
                <span>{{ scope.row.step }}</span>
            </div>
        </template>
    </el-table-column>
    <el-table-column label="类型">
        <template #default="scope">
            <div>
                <span>{{ types[scope.row.type] }}</span>
            </div>
        </template>
    </el-table-column>
    <el-table-column label="图片">
        <template #default="scope">
            <div>
                <el-button type="info" :icon="Picture" @click="queryImg(scope.row.img)">查看</el-button>
            </div>
        </template>
    </el-table-column>
    <el-table-column label="操作">
        <template #default="scope">
            <div>
                <el-button type="success" :icon="Edit" @click="showUpdate(scope.row)">修改</el-button>
                <el-button type="danger" :icon="Delete" @click="delete_dataset(scope.row.id)">删除</el-button>
            </div>
        </template>
    </el-table-column>
</el-table>

<!-- 图片查看框 -->
<el-dialog v-model="imgVisible" title="图片" width="400" draggable="true" id="img-dialog">
    <img :src="imgSrc" width="300" height="300">
</el-dialog>

<!-- 分页器 -->
<el-pagination
background 
layout="prev, pager, next"
:total="data_num"
v-model:current-page="current_page"
v-model:page-size="page_size"
@current-change="handlePageChange()"/>

<!-- 修改框 -->
<el-dialog v-model="updateDialogVisible" title="修改用户信息" width="500" draggable="true">
    <el-form
    :model="updateForm"
    class="demo-form-inline"
    label-width="auto"
    style="margin-left:75px;max-width: 350px;"
    :rules="updateRules"
    >
    <el-form-item label="机构" prop="origin">
        <el-input v-model="updateForm.origin" autocomplete="off" />
    </el-form-item>
    <el-form-item label="日期" prop="date">
        <el-date-picker
        v-model="updateForm.date"
        type="date"
        placeholder="选择年月"
        :disabled-date="pickerOptions"
        :default-value="defaultTime()"
        @change="dateChange_update()">
        </el-date-picker>
    </el-form-item>
    <el-form-item label="预报步长" prop="step">
        <el-select
        v-model="updateForm.step"
        placeholder="请选择步长"
        clearable
        @change="stepChange_update()"
        >
            <el-option label="0-24" value="0-24" />
            <el-option label="24-48" value="24-48" />
            <el-option label="48-72" value="48-72" />
            <el-option label="72-96" value="72-96" />
            <el-option label="96-120" value="96-120" />
            <el-option label="120-144" value="120-144" />
            <el-option label="144-168" value="144-168" />
        </el-select>
    </el-form-item>
    <el-form-item label="类型" prop="type">
        <el-select
            v-model="updateForm.type"
            placeholder="请选择类型"
            clearable
            @change="typeChange_update()"
        >
            <el-option label="原预报数据" value="data" />
            <el-option label="订正结果" value="pred" />
            <el-option label="标签数据" value="label" />
        </el-select>
    </el-form-item>
    </el-form>
    <template #footer>
      <div class="dialog-footer">
        <el-button @click="updateDialogVisible = false">取消</el-button>
        <el-button type="primary" @click="update()">确认</el-button>
      </div>
    </template>
</el-dialog>
</template>

<script setup lang="ts">
import { Store } from "@/store/index"
import { ref, reactive, onBeforeMount } from 'vue'
import { getDataset, getDatasetCount, updateDataset, deleteDataset } from '@/api/api'
import { Picture, Search, Delete, Edit } from '@element-plus/icons-vue'
import { FormRules, ElMessage, ElMessageBox } from 'element-plus'

const store: any = Store()
const sel_table = store.selected_table
const types = reactive<any>({
    'data': '原预报数据', 'pred': '订正结果', 'label': '标签数据'
})

let data_list = ref<any>([])
let data_num = ref<number>(0)
let date_selected = ref<string>('')
let date_selected_add = ref<string>('')
let page_size = ref<number>(10)
let current_page = ref<number>(1)
let updateDialogVisible = ref<boolean>(false)
let imgVisible = ref<boolean>(false)
let imgSrc = ref<string>('')
function queryImg(img: any){
    imgSrc.value = `data:image/svg+xml;base64,${img}`
    imgVisible.value = true
}

let months = reactive<string[]>(['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'])

const ruleForm = reactive({
  origin:'',
  date: '',
  step: '',
  type: ''
})
const ruleForm2 = reactive({
  origin:'',
  date: '',
  step: '',
  type: ''
})

function dateChange(){
    if (ruleForm.date == null || ruleForm.date == undefined)
        ruleForm.date = ''
    else{
        let mon = ruleForm.date.toString().split(' ')[1]
        let day = parseInt(ruleForm.date.toString().split(' ')[2])
        date_selected.value = ruleForm.date.toString().split(' ')[3]+'-'+(months.indexOf(mon)+1).toString()+'-'+day.toString()
    }
}
function stepChange(){
    if (ruleForm.step == undefined) ruleForm.step = ''
}
function typeChange(){
    if (ruleForm.type == undefined) ruleForm.type = ''
}
const defaultTime = () => {
    var now = new Date();
    now.setFullYear(2022);
    now.setMonth(0);
    return now
}
function pickerOptions(value:Date) {
    if (value.getFullYear() === 2022){
        switch(value.getMonth()){
            case 0:
                return !(value.getDate() == 3 || value.getDate() == 6 || value.getDate() == 10 || value.getDate() == 13 || value.getDate() == 17 || 
                value.getDate() == 20 || value.getDate() == 24 || value.getDate() == 27 || value.getDate() == 31);
            case 1:
                return !(value.getDate() == 3 || value.getDate() == 7 || value.getDate() == 10 || value.getDate() == 14 || value.getDate() == 17 || 
                value.getDate() == 21 || value.getDate() == 24 || value.getDate() == 28);
            case 2:
                return !(value.getDate() == 3 || value.getDate() == 7 || value.getDate() == 10 || value.getDate() == 14 || value.getDate() == 17 || 
                value.getDate() == 21 || value.getDate() == 24 || value.getDate() == 28 || value.getDate() == 31);
            case 3:
                return !(value.getDate() == 4 || value.getDate() == 7 || value.getDate() == 11 || value.getDate() == 14 || value.getDate() == 18 || 
                value.getDate() == 21 || value.getDate() == 25 || value.getDate() == 28);
            case 4:
                return !(value.getDate() == 2 || value.getDate() == 5 || value.getDate() == 9 || value.getDate() == 12 || value.getDate() == 16 || 
                value.getDate() == 19 || value.getDate() == 23 || value.getDate() == 26 || value.getDate() == 30);
            case 5:
                return !(value.getDate() == 2 || value.getDate() == 6 || value.getDate() == 9 || value.getDate() == 13 || value.getDate() == 16 || 
                value.getDate() == 20 || value.getDate() == 23 || value.getDate() == 27 || value.getDate() == 30);
            case 6:
                return !(value.getDate() == 4 || value.getDate() == 7 || value.getDate() == 11 || value.getDate() == 14 || value.getDate() == 18 || 
                value.getDate() == 21 || value.getDate() == 25 || value.getDate() == 28);
            case 7:
                return !(value.getDate() == 1 || value.getDate() == 4 || value.getDate() == 8 || value.getDate() == 11 || value.getDate() == 15 || 
                value.getDate() == 18 || value.getDate() == 22 || value.getDate() == 25 || value.getDate() == 29);
            case 8:
                return !(value.getDate() == 1 || value.getDate() == 5 || value.getDate() == 8 || value.getDate() == 12 || value.getDate() == 15 || 
                value.getDate() == 19 || value.getDate() == 22 || value.getDate() == 26 || value.getDate() == 29);
            case 9:
                return !(value.getDate() == 3 || value.getDate() == 6 || value.getDate() == 10 || value.getDate() == 13 || value.getDate() == 17 || 
                value.getDate() == 20 || value.getDate() == 24 || value.getDate() == 27 || value.getDate() == 31);
            case 10:
                return !(value.getDate() == 3 || value.getDate() == 7 || value.getDate() == 10 || value.getDate() == 14 || value.getDate() == 17 || 
                value.getDate() == 21 || value.getDate() == 24 || value.getDate() == 28);
            case 11:
                return !(value.getDate() == 1 || value.getDate() == 5 || value.getDate() == 8 || value.getDate() == 12 || value.getDate() == 15 || 
                value.getDate() == 19 || value.getDate() == 22 || value.getDate() == 26 || value.getDate() == 29);
        }
    } else {
        return true;
    }
}

//分页
async function handlePageChange(){
    const formData = new FormData()
    formData.append('origin', ruleForm2.origin)
    formData.append('date', ruleForm2.date)
    formData.append('step', ruleForm2.step)
    formData.append('type', ruleForm2.type)
    formData.append('pageOrder', current_page.value.toString())
    formData.append('pageSize', page_size.value.toString())
    await getDataset(formData).then((response: any)=>{
      data_list.value = response.data
    })
}

//查看
async function query(){
    const formData = new FormData()
    formData.append('origin', ruleForm.origin)
    formData.append('date', date_selected.value)
    formData.append('step', ruleForm.step)
    formData.append('type', ruleForm.type)
    await getDatasetCount(formData).then((response2: any)=>{
        data_num.value = response2.data
    })
    formData.append('pageOrder', '1')
    formData.append('pageSize', page_size.value.toString())

    ruleForm2.origin = ruleForm.origin
    ruleForm2.date = date_selected.value
    ruleForm2.step = ruleForm.step
    ruleForm2.type = ruleForm.type
    current_page.value = 1
    await getDataset(formData).then((response: any)=>{
      data_list.value = response.data
    })
}

//修改
const updateForm = reactive({
  origin:'',
  date: '',
  step:'',
  type: ''
})
let is_right_origin = ref<boolean>(false)
let is_right_date = ref<boolean>(false)
let is_right_step = ref<boolean>(false)
let is_right_type = ref<boolean>(false)
let update_id = ref<number>(0)

const validateOrigin = (rule: any, value: any, callback: any) => {
  if (value === '') {
    is_right_origin.value = false
    callback(new Error('请填写机构名'))
  } else{
    is_right_origin.value = true
    callback()
  }
}

const validateStep = (rule: any, value: any, callback: any) => {
  if (value === '') {
    is_right_step.value = false
    callback(new Error('请选择预报步长'))
  } else{
    is_right_step.value = true
    callback()
  }
}

const validateType = (rule: any, value: any, callback: any) => {
  if (value === '') {
    is_right_type.value = false
    callback(new Error('请选择类型'))
  } else{
    is_right_type.value = true
    callback()
  }
}

const updateRules = reactive<FormRules<typeof updateForm>>({
    origin: [{ validator: validateOrigin, trigger: 'change' }],
    // date: [{ validator: validateDate, trigger: 'change' }],
    step: [{ validator: validateStep, trigger: 'change' }],
    type: [{ validator: validateType, trigger: 'change' }]
})

function dateChange_update(){
    if (updateForm.date == null || updateForm.date == undefined)
        updateForm.date = ''
    else{
        let mon = updateForm.date.toString().split(' ')[1]
        let day = parseInt(updateForm.date.toString().split(' ')[2])
        date_selected_add.value = updateForm.date.toString().split(' ')[3]+'-'+(months.indexOf(mon)+1).toString()+'-'+day.toString()
    }
}
function stepChange_update(){
    if (updateForm.step == undefined) updateForm.step = ''
}
function typeChange_update(){
    if (updateForm.type == undefined) updateForm.type = ''
}

function showUpdate(row: any){      //展示修改框
    updateDialogVisible.value = true
    updateForm.origin = row.origin
    updateForm.date = row.date
    updateForm.step = row.step
    updateForm.type = row.type
    update_id.value = row.id
    is_right_origin.value = true
    is_right_date.value = true
    is_right_step.value = true
    is_right_type.value = true
}

async function update(){
    if (is_right_origin.value && is_right_step.value && is_right_type.value && updateForm.date !== ''){
        const formData = new FormData()
        formData.append('id', update_id.value.toString())
        formData.append('origin', updateForm.origin)
        formData.append('date', date_selected_add.value)
        formData.append('step', updateForm.step)
        formData.append('type', updateForm.type)
        formData.append('pageOrder', current_page.value.toString())
        formData.append('pageSize', page_size.value.toString())
        formData.append('origin2', ruleForm2.origin)
        formData.append('date2', ruleForm2.date)
        formData.append('step2', ruleForm2.step)
        formData.append('type2', ruleForm2.type)
        await updateDataset(formData).then((response: any)=>{
            if(response.data != null){
                data_list.value = response.data
                updateDialogVisible.value = false
                ElMessage.success('修改数据成功')
                is_right_origin.value = false
                is_right_date.value = false
                is_right_step.value = false
                is_right_type.value = false
            } else {
                ElMessage.error('修改数据失败')
            }
        })
    }
    else if (updateForm.date === ''){
        ElMessage.error('请选择日期')
    }
    else {
        ElMessage.error('请填写正确的信息')
    }
}

//删除
function delete_dataset(id: string){
    ElMessageBox.confirm('你确定要删除这一行的数据吗?','删除数据',
        {
            confirmButtonText: '删除',
            cancelButtonText: '取消',
            type: 'warning',
        }
    )
    .then(async() => {
        const formData = new FormData()
        formData.append('id', id)
        formData.append('origin', ruleForm2.origin)
        formData.append('date', ruleForm2.date)
        formData.append('step', ruleForm2.step)
        formData.append('type', ruleForm2.type)
        formData.append('pageOrder', current_page.value.toString())
        formData.append('pageSize', page_size.value.toString())
        await deleteDataset(formData).then((response: any)=>{
            if (response.data != null){
                data_list.value = response.data
                data_num.value -= 1
                ElMessage.success('删除数据成功')
                if (Math.ceil(data_num.value / page_size.value) < current_page.value &&
                Math.ceil(data_num.value / page_size.value) != 0) {
                    current_page.value -= 1
                }
            } else {
                ElMessage.error('删除数据失败')
            }
        })
    })
    .catch(() => {
      // catch error
    })
}
//加载数据
onBeforeMount(async()=>{
    const formData = new FormData()
    formData.append('origin', ruleForm.origin)
    formData.append('date', date_selected.value)
    formData.append('step', ruleForm.step)
    formData.append('type', ruleForm.type)
    await getDatasetCount(formData).then((response2: any)=>{
        data_num.value = response2.data
    })
    formData.append('pageOrder', '1')
    formData.append('pageSize', page_size.value.toString())
    await getDataset(formData).then((response: any)=>{
      data_list.value = response.data
    })
})
</script>

<style>
#sel-table{
    color:black;
    font-size: 15px;
    margin-top: 20px;
    margin-bottom: 10px;
}
.demo-form-inline .el-input {
  --el-input-width: 150px;
}
.demo-form-inline .el-select {
  --el-select-width: 120px;
}
#img-dialog img{
    margin-left: 36px;
}
.el-pagination{
    margin-top:20px;
    justify-content: center;
}
.el-table .el-button{
    width:70px;
}
</style>