<template>
    <div id="chart"></div>
</template>

<script lang="ts" setup>
import * as echarts from 'echarts'
import { onMounted } from 'vue'

onMounted(()=>{
    var myChart1 = echarts.init(document.getElementById('chart'));

    var option1 = {
      title: {
        text: 'S-CUnet 3+模型MAE和RMSE折线图',
        left: 'center'
      },
      tooltip: {
        trigger: 'axis'
      },
      legend: {
        data: ['MAE', 'RMSE'],
        top: 'bottom'
      },
      xAxis: {
        type: 'category',
        data: ['0-24', '24-48', '48-72', '72-96', '96-120', '120-144', '144-168']
      },
      yAxis: {
        type: 'value',
        name: 'MAE/RMSE'
      },
      series: [
        {
          name: 'MAE',
          type: 'line',
          data: [1.0664, 1.1750, 1.2885, 1.3864, 1.5574, 1.7041, 1.8774]
        },
        {
          name: 'RMSE',
          type: 'line',
          data: [1.4417, 1.5690, 1.7130, 1.8468, 2.0843, 2.2584, 2.5039]
        },
      ]
    }

    myChart1.setOption(option1);
  })
</script>

<style scoped>
#chart{
  width: 600px; 
  height: 400px;
  display: inline-block;
  margin-top: 20px;
}
</style>