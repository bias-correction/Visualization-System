<template>
  <router-view></router-view>
</template>

<script lang="ts" setup>
import { ref, onBeforeMount, onMounted } from 'vue'
import main_vision from '@/pages/main_vision.vue'
import { getUser } from "@/api/api"
import {Store} from "@/store/index"

const store: any = Store()
const main = ref(main_vision)

</script>

<style>
body{
    background: url('./assets/img/background.png');
    background-repeat: no-repeat;
    background-size:120em 70em;
}
</style>
