package org.example.test;

import org.example.controller.UserController;
import org.example.service.Impl.UserServiceImpl;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import java.util.*;

@SpringBootTest
public class userTest {

    @Autowired
    UserServiceImpl userService;

    @Autowired
    UserController userController;
    @Test
    public void queryAll() {
        userService.queryAll().forEach(System.out::println);
    }

    @Test
    public void select(){
        Map<String, String> p = new HashMap<>();
        p.put("username", "");
        p.put("phone", "");
        p.put("sex", "");
        p.put("education", "");
        p.put("address", "");
        p.put("pageOrder", "2");
        p.put("pageSize", "5");

        System.out.println(userController.getUser(p));
        System.out.println(userController.getUser(p).size());
    }

    @Test
    public void getCount(){
        Map<String, String> p = new HashMap<>();
        p.put("username", "");
        p.put("phone", "");
        p.put("sex", "");
        p.put("education", "");
        p.put("address", "");
        System.out.println(userController.getUserCount(p));
    }
}
