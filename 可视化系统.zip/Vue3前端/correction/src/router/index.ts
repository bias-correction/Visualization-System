import { createRouter,createWebHashHistory } from "vue-router"
import {Store} from "@/store/index"
import component from "element-plus/es/components/tree-select/src/tree-select-option.mjs"

const routes = [
    {
        path:'/',
        redirect:'/main_vision'
    },
    {
        path:'/main_vision',
        name:'main_vision',
        component:()=>import('@/pages/main_vision.vue'),
        children:[
            {
                path:'/main_vision',
                redirect:'/correct_show'
            },
            {
                path:'/correct_show',
                name:'correct_show',
                component:()=>import('@/pages/correct_show.vue')
            },
            {
                path:'/introduction',
                name:'introduction',
                component:()=>import('@/pages/introduction.vue')
            },
            {
                path:'/pingjia',
                name:'pingjia',
                component:()=>import('@/pages/pingjia.vue')
            },
        ]
    },
    {
        path:'/login',
        name:'login',
        component:()=>import('@/pages/login.vue'),
        meta:{
            title:'登录'
        }
    },
    {
        path:'/data_manage',
        name:'data_manage',
        component:()=>import('@/pages/data_manage.vue'),
        meta:{
            title:'数据管理'
        },
        children:[
            {
                path:'/data_manage',
                redirect:'/data_manage/user'
            },
            {
                path:'/data_manage/user',
                name:'user',
                component:()=>import('@/pages/user.vue'),
                meta:{
                    title:'数据管理'
                },
            },
            {
                path:'/data_manage/dataset',
                name:'dataset',
                component:()=>import('@/pages/dataset.vue'),
                meta:{
                    title:'数据管理'
                },
            },
            {
                path:'/data_manage/result',
                name:'result',
                component:()=>import('@/pages/result.vue'),
                meta:{
                    title:'数据管理'
                },
            }
        ]
    }
]

const router = createRouter({
    history:createWebHashHistory(),
    routes
  })

router.beforeEach((to, from, next)=>{
    const store: any = Store()
    if(to.name == 'correct_show'){
        store.set_disable(0)
    }else{
        const store: any = Store()
        store.set_disable(1)
    }
    if(to.name == 'login' || to.path.split('/')[1] == 'data_manage'){
        document.title = to.meta.title
    }
    if(to.name == 'user' || to.name == 'dataset' || to.name == 'result'){
        store.selected_table = store.tables[to.name]
        console.log(store.selected_table)
    }
    next()
})

export default router