<template>
    <div>
      <table>
        <tr v-if="img_data!='暂无图片'">
            <td>
                <span style="font-size: 20px;font-family: '楷体';vertical-align: middle;">预报步长：</span>
                <el-select
                    v-model="value"
                    placeholder="选择预报步长"
                    size="large"
                    style="width: 160px"
                    @change="change_step()"
                >
                    <el-option
                        v-for="item in options"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value"
                    />
                </el-select>
                <!-- <el-button type="primary" @click="change_step()" style="margin-left: 10px;">确认</el-button> -->
            </td>
        </tr>
          <tr>
              <td style="width:30%">
                  <h1 style="color:red; font-family:'楷体'">预报值</h1>
              </td>
              <td style="width: 5%;"></td>
              <td style="width:30%">
                  <h1 style="color:green;font-family:'楷体'">订正值</h1>
              </td>
              <td style="width: 5%;"></td>
              <td>
                  <h1 style="color:blue;font-family:'楷体'">真实值</h1>
              </td>
          </tr>
          <tr class="image">
              <td>
                <el-container v-loading="is_loading">
                    <p v-if="img_data=='暂无图片'">{{ img_data }}</p>
                    <img v-else :src='img_data' width="300" height="300">
                </el-container>
              </td>
              <td style="width: 10px;">
                  
              </td>
              <td>
                <el-container v-loading="is_loading">
                    <p v-if="img_correct=='暂无图片'">{{ img_correct }}</p>
                    <img v-else :src='img_correct' width="300" height="300">
                </el-container>
              </td>
              <td style="width: 10px;">
                  
              </td>
              <td>
                <el-container v-loading="is_loading">
                    <p v-if="img_truth=='暂无图片'">{{ img_truth }}</p>
                    <img v-else :src='img_truth' width="300" height="300">
                </el-container>
              </td>
          </tr>
          <tr>
              <td colspan="5">
                  <img v-if="img_truth!='暂无图片'" :src='colorbar_img' width="600" height="50" class="colorbar">
              </td>
          </tr>
      </table>
    </div>
  </template>
  
<script lang="ts" setup>
  import {Store} from "@/store/index"
  import { computed, ref } from 'vue'
  import { ElNotification } from 'element-plus'
  import { changeStep } from '@/api/api'
  import pubsub from 'pubsub-js'

  const store: any = Store()
  const value = ref<string>('0-24')
  let is_loading = computed(()=>{
    return store.is_loading
  })
  pubsub.subscribe('getStep', function(name: string, step: string){
    value.value = step
  })
  const options: any = [
    {
        value: '0-24',
        label: '0-24'
    },
    {
        value: '24-48',
        label: '24-48'
    },
    {
        value: '48-72',
        label: '48-72'
    },
    {
        value: '72-96',
        label: '72-96'
    },
    {
        value: '96-120',
        label: '96-120'
    },
    {
        value: '120-144',
        label: '120-144'
    },
    {
        value: '144-168',
        label: '144-168'
    }
  ]
  let img_data = computed(()=>{
    return store.src_data == '' ?'暂无图片':store.src_data
  })
  let img_correct = computed(()=>{
    return store.src_correct == '' ?'暂无图片':store.src_correct
  })
  let img_truth = computed(()=>{
    return store.src_truth == '' ?'暂无图片':store.src_truth
  })
  let colorbar_img = computed(()=>{
    const img = new URL('@/assets/img3/colorbar.png', import.meta.url).href
    return store.date == '' ?'none':img
  })
  async function change_step() {
    const formData = new FormData()
    formData.append("date", store.date)
    formData.append("step", value.value)
    store.is_loading = true
    store.disabled = true
    await changeStep(formData).then((response: any)=>{
        if (response.data.error){
            ElNotification.error({
                title: '查询错误',
                message: response.data.error
            })
        }
        else{
            store.getImg([
                store.date,
                value.value,
                `data:image/svg+xml;base64,${response.data.data.split('\'')[1]}`,
                `data:image/svg+xml;base64,${response.data.pred.split('\'')[1]}`,
                `data:image/svg+xml;base64,${response.data.label.split('\'')[1]}`
            ])
        }
    })
    store.disabled = false
    store.is_loading = false
  }
</script>
  
<style scoped>
table{
    margin-top: 10px;
    width:100%;
}
table td .el-container{
    justify-content: center;
    align-items: center;
    margin: auto;
    width:300px;
    height: 300px;
}
.image{
    height: 300px;
    text-align: center;
}
#sliderContainer{
    width: 400px;
    margin:auto;
}
.colorbar{
    text-align: center;
    margin-top: 50px;
}
</style>