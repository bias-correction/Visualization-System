import axios from 'axios'

//user表格
export const sendCode = (phone:string)=>{ 
    return axios.get(`http://127.0.0.1:8081/code?memPhone=${phone}`)
}

export const validate = (data:FormData)=>{
    return axios.post('http://127.0.0.1:8081/validate', data)
}

export const getUser = (data:FormData)=>{
    return axios.post('http://127.0.0.1:8081/getuser', data)
}

export const addUser = (data:FormData)=>{
    return axios.post('http://127.0.0.1:8081/addUser', data)
}

export const updateUser = (data:FormData)=>{
    return axios.post('http://127.0.0.1:8081/updateUser', data)
}

export const deleteUser = (data:FormData)=>{
    return axios.post('http://127.0.0.1:8081/deleteUser', data)
}

export const getUserCount = (data:FormData)=>{
    return axios.post('http://127.0.0.1:8081/getUserCount', data)
}

//dataset表格
export const getDatasetCount = (data:FormData)=>{
    return axios.post('http://127.0.0.1:8081/getDatasetCount', data)
}

export const getDataset = (data:FormData)=>{
    return axios.post('http://127.0.0.1:8081/getDataset', data)
}

export const updateDataset = (data:FormData)=>{
    return axios.post('http://127.0.0.1:8081/updateDataset', data)
}

export const deleteDataset = (data:FormData)=>{
    return axios.post('http://127.0.0.1:8081/deleteDataset', data)
}

//Django
export const getResult = (data:FormData)=>{
    return axios.post('http://127.0.0.1:8000/getResult/', data)
}

export const changeStep = (data:FormData)=>{
    return axios.post('http://127.0.0.1:8000/changeStep/', data)
}

export const download = ()=>{
    return axios.get('http://127.0.0.1:8000/download/', {
        responseType: 'blob', // 确保 axios 以 Blob 格式接收响应
    })
}