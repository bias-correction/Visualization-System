import netCDF4
import numpy as np
import torch
import torch.nn as nn
from SU_ViT_3plus_emb import SU_ViT_3plus_emb

data = torch.from_numpy(netCDF4.Dataset("../dataset/CMA.nc")['data'][0, :, 0, :, :]).unsqueeze(0).unsqueeze(2)
label = torch.from_numpy(netCDF4.Dataset("../dataset/CMA.nc")['data'][0, :, 2, :, :]).unsqueeze(0).unsqueeze(2)
time = ['0-24', '24-48', '48-72', '72-96', '96-120', '120-144', '144-168']
loss_func1 = nn.L1Loss()
loss_func2 = nn.MSELoss()
model = SU_ViT_3plus_emb().to('cuda:0')
model.load_state_dict(torch.load('ft_batch_1_SU-ViT-3+-emb_epoch_20_gamma_0.98_Smooth_best.pth'))
model.eval()
for t in range(7):
    data_ = torch.tensor(data).to('cuda:0')[:, t:t+1, :, :, :]
    label_ = torch.tensor(label).to('cuda:0')[:, t:t+1, :, :, :]
    pred = model(data_, time[t:t + 1])
    loss_mae_val = loss_func1(pred, label_)
    loss_rmse_val = torch.sqrt(loss_func2(pred, label_))
    print(loss_mae_val, loss_rmse_val)
