<template>
<h5 id="sel-table">{{ sel_table }}</h5>
<el-form
:model="ruleForm"
class="demo-form-inline"
:inline="true"
>
<el-form-item label="管理员名字" prop="username">
    <el-input v-model="ruleForm.username" autocomplete="off" />
</el-form-item>
<el-form-item label="联系方式" prop="phone">
    <el-input v-model="ruleForm.phone" autocomplete="off" />
</el-form-item>
<el-form-item label="性别" prop="sex">
    <el-select
        v-model="ruleForm.sex"
        placeholder="请选择性别"
        clearable
        @change="sexChange()"
      >
        <el-option label="男" value="男" />
        <el-option label="女" value="女" />
      </el-select>
</el-form-item>
<el-form-item label="学历" prop="education">
    <el-select
        v-model="ruleForm.education"
        placeholder="请选择学历"
        clearable
        @change="eduChange()"
      >
        <el-option label="高中及以下" value="高中及以下" />
        <el-option label="专科" value="专科" />
        <el-option label="本科" value="本科" />
        <el-option label="硕士" value="硕士" />
        <el-option label="博士及以上" value="博士及以上" />
      </el-select>
</el-form-item>
<el-form-item label="住址" prop="address">
    <el-input v-model="ruleForm.address" autocomplete="off" />
</el-form-item>
<el-form-item>
    <el-button type="primary" @click="query()" :icon="Search">查询</el-button>
</el-form-item>
<el-form-item>
    <el-button type="success" @click="addDialogVisible = true" :icon="Plus">添加</el-button>
</el-form-item>
</el-form>

<el-table style="width: 100%" :data="data_list">
    <el-table-column label="序号">
        <template #default="scope">
            <div>
                <span>{{ scope.row.id }}</span>
            </div>
        </template>
    </el-table-column>
    <el-table-column label="管理员名字">
        <template #default="scope">
            <div>
                <span>{{ scope.row.username }}</span>
            </div>
        </template>
    </el-table-column>
    <el-table-column label="联系方式">
        <template #default="scope">
            <div>
                <span>{{ scope.row.phone }}</span>
            </div>
        </template>
    </el-table-column>
    <el-table-column label="性别">
        <template #default="scope">
            <div>
                <span>{{ scope.row.sex }}</span>
            </div>
        </template>
    </el-table-column>
    <el-table-column label="学历">
        <template #default="scope">
            <div>
                <span>{{ scope.row.education }}</span>
            </div>
        </template>
    </el-table-column>
    <el-table-column label="住址">
        <template #default="scope">
            <div>
                <span>{{ scope.row.address }}</span>
            </div>
        </template>
    </el-table-column>
    <el-table-column label="操作">
        <template #default="scope">
            <div>
                <el-button type="info" :icon="Edit" @click="showUpdate(scope.row)">修改</el-button>
                <el-button type="danger" :icon="Delete" @click="deleteUser(scope.row.id)">删除</el-button>
            </div>
        </template>
    </el-table-column>
</el-table>
<!-- 分页器 -->
<el-pagination 
background 
layout="prev, pager, next" 
:total="data_num"
v-model:current-page="current_page"
v-model:page-size="page_size"
@current-change="handlePageChange()"/>

<!-- 添加框 -->
<el-dialog v-model="addDialogVisible" title="添加用户" width="500" draggable="true">
    <el-form
    :model="addForm"
    class="demo-form-inline"
    label-width="auto"
    style="margin-left:75px;max-width: 350px;"
    :rules="addRules"
    >
    <el-form-item label="管理员名字" prop="username">
        <el-input v-model="addForm.username" autocomplete="off" />
    </el-form-item>
    <el-form-item label="联系方式" prop="phone">
        <el-input v-model="addForm.phone" autocomplete="off" />
    </el-form-item>
    <el-form-item label="密码" prop="password">
        <el-input v-model="addForm.password" type="password" autocomplete="off" />
    </el-form-item>
    <el-form-item label="确认密码" prop="confirm">
        <el-input v-model="addForm.confirm" type="password" autocomplete="off" />
    </el-form-item>
    <el-form-item label="性别" prop="sex">
        <el-select
            v-model="addForm.sex"
            placeholder="请选择性别"
            clearable
        >
            <el-option label="男" value="男" />
            <el-option label="女" value="女" />
        </el-select>
    </el-form-item>
    <el-form-item label="学历" prop="education">
        <el-select
            v-model="addForm.education"
            placeholder="请选择学历"
            clearable
        >
            <el-option label="高中及以下" value="高中及以下" />
            <el-option label="专科" value="专科" />
            <el-option label="本科" value="本科" />
            <el-option label="硕士" value="硕士" />
            <el-option label="博士及以上" value="博士及以上" />
        </el-select>
    </el-form-item>
    <el-form-item label="住址" prop="address">
        <el-input v-model="addForm.address" type="textarea" autocomplete="off" />
    </el-form-item>
    </el-form>
    <template #footer>
      <div class="dialog-footer">
        <el-button @click="addDialogVisible = false">取消</el-button>
        <el-button type="primary" @click="add()">确认</el-button>
      </div>
    </template>
</el-dialog>

<!-- 修改框 -->
<el-dialog v-model="updateDialogVisible" title="修改用户信息" width="500" draggable="true">
    <el-form
    :model="updateForm"
    class="demo-form-inline"
    label-width="auto"
    style="margin-left:75px;max-width: 350px;"
    :rules="updateRules"
    >
    <el-form-item label="管理员名字" prop="username">
        <el-input v-model="updateForm.username" autocomplete="off" />
    </el-form-item>
    <el-form-item label="联系方式" prop="phone">
        <el-input v-model="updateForm.phone" autocomplete="off" />
    </el-form-item>
    <el-form-item label="密码" prop="password">
        <el-input v-model="updateForm.password" type="password" autocomplete="off" />
    </el-form-item>
    <el-form-item label="性别" prop="sex">
        <el-select
            v-model="updateForm.sex"
            placeholder="请选择性别"
            clearable
        >
            <el-option label="男" value="男" />
            <el-option label="女" value="女" />
        </el-select>
    </el-form-item>
    <el-form-item label="学历" prop="education">
        <el-select
            v-model="updateForm.education"
            placeholder="请选择学历"
            clearable
        >
            <el-option label="高中及以下" value="高中及以下" />
            <el-option label="专科" value="专科" />
            <el-option label="本科" value="本科" />
            <el-option label="硕士" value="硕士" />
            <el-option label="博士及以上" value="博士及以上" />
        </el-select>
    </el-form-item>
    <el-form-item label="住址" prop="address">
        <el-input v-model="updateForm.address" type="textarea" autocomplete="off" />
    </el-form-item>
    </el-form>
    <template #footer>
      <div class="dialog-footer">
        <el-button @click="updateDialogVisible = false">取消</el-button>
        <el-button type="primary" @click="update()">确认</el-button>
      </div>
    </template>
</el-dialog>
</template>

<script setup lang="ts">
import { ref, reactive, onBeforeMount } from 'vue';
import { getUser, addUser, getUserCount, updateUser, deleteUser } from "@/api/api"
import { Delete, Edit, Plus, Search } from '@element-plus/icons-vue'
import { FormRules, ElMessage, ElMessageBox } from 'element-plus'
import {Store} from "@/store/index"

const store: any = Store()
const sel_table = store.selected_table
let data_list = ref<any>([])
let data_num = ref<number>(0)
let current_page = ref<number>(1)
let page_size = ref<number>(10)
let addDialogVisible = ref<boolean>(false)
let updateDialogVisible = ref<boolean>(false)
let is_right_username = ref<boolean>(false)
let is_right_phone = ref<boolean>(false)
let is_right_password = ref<boolean>(false)
let is_right_confirm = ref<boolean>(false)
let is_right_sex = ref<boolean>(false)
let is_right_edu = ref<boolean>(false)
let is_right_address = ref<boolean>(false)
let update_id = ref<number>(0)
//验证添加对话框的选项
const reg_phone = /^1[3456789]\d{9}$/
const reg_password = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/
const validateUsername = (rule: any, value: any, callback: any) => {
  if (value === '') {
    is_right_username.value = false
    callback(new Error('请输入用户名'))
  } else if(value.length < 5){
    is_right_username.value = false
    callback(new Error('用户名至少5个字符'))
  } else{
    is_right_username.value = true
    callback()
  }
}

const validatePhone = (rule: any, value: any, callback: any) => {
  if (value === '') {
    is_right_phone.value = false
    callback(new Error('请输入联系方式'))
  } else if(!reg_phone.test(value)){
    is_right_phone.value = false
    callback(new Error('联系方式格式不对'))
  } else{
    is_right_phone.value = true
    callback()
  }
}

const validatePassword = (rule: any, value: any, callback: any) => {
  if (value === '') {
    is_right_password.value = false
    callback(new Error('请输入密码'))
  } else if(!reg_password.test(value)){
    is_right_password.value = false
    callback(new Error('密码必须包含大小写字母和数字，长度不少于8位'))
  } else{
    is_right_password.value = true
    callback()
  }
}

const validateConfirm = (rule: any, value: any, callback: any) => {
  if (value === '') {
    is_right_confirm.value = false
    callback(new Error('请再次输入密码'))
  } else if(value !== addForm.password){
    is_right_confirm.value = false
    callback(new Error('确认密码必须与密码一样'))
  } else{
    is_right_confirm.value = true
    callback()
  }
}

const validateSex = (rule: any, value: any, callback: any) => {
  if (value === '' || value === undefined) {
    is_right_sex.value = false
    callback(new Error('请选择性别'))
  } else{
    is_right_sex.value = true
    callback()
  }
}

const validateEducation = (rule: any, value: any, callback: any) => {
  if (value === '' || value === undefined) {
    is_right_edu.value = false
    callback(new Error('请选择学历'))
  } else{
    is_right_edu.value = true
    callback()
  }
}

const validateAddress = (rule: any, value: any, callback: any) => {
  if (value === '') {
    is_right_address.value = false
    callback(new Error('请填写住址'))
  } else{
    is_right_address.value = true
    callback()
  }
}

const ruleForm = reactive({
  username:'',
  phone: '',
  password: '',
  sex: '',
  education:'',
  address:''
})
//查看所用的存储信息
const ruleForm2 = reactive({
  username:'',
  phone: '',
  sex: '',
  education:'',
  address:''
})
//分页
async function handlePageChange(){
    console.log(current_page.value)
    const formData = new FormData()
    formData.append('username', ruleForm2.username)
    formData.append('phone', ruleForm2.phone)
    formData.append('sex', ruleForm2.sex)
    formData.append('education', ruleForm2.education)
    formData.append('address', ruleForm2.address)
    formData.append('pageOrder', current_page.value.toString())
    formData.append('pageSize', page_size.value.toString())
    await getUser(formData).then((response: any)=>{
      data_list.value = response.data
    })
}
//添加
const addForm = reactive({
  username:'',
  phone: '',
  password:'',
  confirm:'',
  sex: '',
  education:'',
  address:''
})

async function add(){
    if (is_right_username.value && is_right_phone.value && is_right_password.value && is_right_confirm.value && is_right_sex.value && is_right_edu.value && is_right_address.value){
        const formData = new FormData()
        formData.append('username', addForm.username)
        formData.append('phone', addForm.phone)
        formData.append('password', addForm.password)
        formData.append('sex', addForm.sex)
        formData.append('education', addForm.education)
        formData.append('address', addForm.address)
        formData.append('pageOrder', current_page.value.toString())
        formData.append('pageSize', page_size.value.toString())
        await addUser(formData).then((response: any)=>{
            if(response.data != null){
                data_list.value = response.data
                addDialogVisible.value = false
                data_num.value += 1
                ElMessage.success('添加数据成功')
                addForm.username = ''
                addForm.phone = ''
                addForm.password = ''
                addForm.confirm = ''
                addForm.sex = ''
                addForm.education = ''
                addForm.address = ''
            } else {
                ElMessage.error('添加数据失败')
            }
        })
    } else {
        ElMessage.error('请填写正确的信息')
    }
}

const addRules = reactive<FormRules<typeof addForm>>({
    username: [{ validator: validateUsername, trigger: 'blur' }],
    phone: [{ validator: validatePhone, trigger: 'blur' }],
    password: [{ validator: validatePassword, trigger: 'blur' }],
    confirm: [{ validator: validateConfirm, trigger: 'blur' }],
    sex: [{ validator: validateSex, trigger: 'change' }],
    education: [{ validator: validateEducation, trigger: 'change' }],
    address: [{ validator: validateAddress, trigger: 'blur' }]
})
//修改
const updateForm = reactive({
  username:'',
  phone: '',
  password:'',
  sex: '',
  education:'',
  address:''
})

function showUpdate(row: any){
    updateDialogVisible.value = true
    updateForm.username = row.username
    updateForm.phone = row.phone
    updateForm.password = row.password
    updateForm.sex = row.sex
    updateForm.education = row.education
    updateForm.address = row.address
    update_id.value = row.id
    is_right_username.value = true
    is_right_phone.value = true
    is_right_password.value = true
    is_right_sex.value = true
    is_right_edu.value = true
    is_right_address.value = true
}

async function update(){
    if (is_right_username.value && is_right_phone.value && is_right_password.value && is_right_sex.value && is_right_edu.value && is_right_address.value){
        const formData = new FormData()
        formData.append('id', update_id.value.toString())
        formData.append('username', updateForm.username)
        formData.append('phone', updateForm.phone)
        formData.append('password', updateForm.password)
        formData.append('sex', updateForm.sex)
        formData.append('education', updateForm.education)
        formData.append('address', updateForm.address)
        formData.append('pageOrder', current_page.value.toString())
        formData.append('pageSize', page_size.value.toString())
        formData.append('username2', ruleForm2.username)
        formData.append('phone2', ruleForm2.phone)
        formData.append('sex2', ruleForm2.sex)
        formData.append('education2', ruleForm2.education)
        formData.append('address2', ruleForm2.address)
        await updateUser(formData).then((response: any)=>{
            if(response.data != null){
                data_list.value = response.data
                updateDialogVisible.value = false
                ElMessage.success('修改数据成功')
                is_right_username.value = false
                is_right_phone.value = false
                is_right_password.value = false
                is_right_sex.value = false
                is_right_edu.value = false
                is_right_address.value = false
            } else {
                ElMessage.error('修改数据失败')
            }
        })
    } else {
        ElMessage.error('请填写正确的信息')
    }
}

const updateRules = reactive<FormRules<typeof updateForm>>({
    username: [{ validator: validateUsername, trigger: 'change' }],
    phone: [{ validator: validatePhone, trigger: 'change' }],
    password: [{ validator: validatePassword, trigger: 'change' }],
    sex: [{ validator: validateSex, trigger: 'change' }],
    education: [{ validator: validateEducation, trigger: 'change' }],
    address: [{ validator: validateAddress, trigger: 'change' }]
})
//查看
async function query(){
    const formData = new FormData()
    formData.append('username', ruleForm.username)
    formData.append('phone', ruleForm.phone)
    formData.append('sex', ruleForm.sex)
    formData.append('education', ruleForm.education)
    formData.append('address', ruleForm.address)
    await getUserCount(formData).then((response2: any)=>{
        data_num.value = response2.data
    })
    formData.append('pageOrder', '1')
    formData.append('pageSize', page_size.value.toString())

    ruleForm2.username = ruleForm.username
    ruleForm2.phone = ruleForm.phone
    ruleForm2.sex = ruleForm.sex
    ruleForm2.education = ruleForm.education
    ruleForm2.address = ruleForm.address
    current_page.value = 1
    await getUser(formData).then((response: any)=>{
      data_list.value = response.data
    })
}
//删除
function deleteUser(id: string){
    ElMessageBox.confirm('你确定要删除这一行的数据吗?','删除数据',
        {
            confirmButtonText: '删除',
            cancelButtonText: '取消',
            type: 'warning',
        }
    )
    .then(async() => {
        const formData = new FormData()
        formData.append('id', id)
        formData.append('username', ruleForm2.username)
        formData.append('phone', ruleForm2.phone)
        formData.append('sex', ruleForm2.sex)
        formData.append('education', ruleForm2.education)
        formData.append('address', ruleForm2.address)
        formData.append('pageOrder', current_page.value.toString())
        formData.append('pageSize', page_size.value.toString())
        await deleteUser(formData).then((response: any)=>{
            if (response.data != null){
                data_list.value = response.data
                data_num.value -= 1
                ElMessage.success('删除数据成功')
                if (Math.ceil(data_num.value / page_size.value) < current_page.value &&
                Math.ceil(data_num.value / page_size.value) != 0) {
                    current_page.value -= 1
                }
            } else {
                ElMessage.error('删除数据失败')
            }
        })
    })
    .catch(() => {
      // catch error
    })
    

}

function sexChange(){
    if (ruleForm.sex == undefined) ruleForm.sex = ''
}

function eduChange(){
    if (ruleForm.education == undefined) ruleForm.education = ''
}

onBeforeMount(async()=>{
    const formData = new FormData()
    formData.append('username', ruleForm.username)
    formData.append('phone', ruleForm.phone)
    formData.append('sex', ruleForm.sex)
    formData.append('education', ruleForm.education)
    formData.append('address', ruleForm.address)
    await getUserCount(formData).then((response2: any)=>{
        data_num.value = response2.data
    })
    formData.append('pageOrder', '1')
    formData.append('pageSize', page_size.value.toString())
    await getUser(formData).then((response: any)=>{
      data_list.value = response.data
    })
    
})
</script>

<style scoped>
#sel-table{
    color:black;
    font-size: 15px;
    margin-top: 20px;
    margin-bottom: 10px;
}
.demo-form-inline .el-input {
  --el-input-width: 150px;
}
.demo-form-inline .el-select {
  --el-select-width: 120px;
}
.el-pagination{
    margin-top:20px;
    justify-content: center;
}
.el-table .el-button{
    width:70px;
}
</style>