import os
from django.http import JsonResponse, HttpResponse
from correct import models
from datetime import datetime
import netCDF4
import torch
import io
import matplotlib.pyplot as plt
import base64

from .utils.code.SU_ViT_3plus_emb import SU_ViT_3plus_emb
from .utils.code.data_list import data_list

data = torch.from_numpy(
    netCDF4.Dataset(r"D:\可视化系统\后端 Django\correction\correct\utils\dataset\dataset.nc").variables['data'][:, :, 0, :,
    :]).unsqueeze(2)
label = torch.from_numpy(
    netCDF4.Dataset(r"D:\可视化系统\后端 Django\correction\correct\utils\dataset\dataset.nc").variables['data'][:, :, 1, :,
    :]).unsqueeze(2)
time = ['0-24', '24-48', '48-72', '72-96', '96-120', '120-144', '144-168']
model = SU_ViT_3plus_emb().to('cuda:0')
model.load_state_dict(torch.load(
    'D:\\可视化系统\\后端 Django\\correction\\correct\\utils\\code\\ft_batch_1_SU-ViT-3+-emb_epoch_20_gamma_0.98_Smooth_best.pth'))
model.eval()

#     #1.添加数据
#     # models.Model.objects.create(name='U-Net', size=45)
#     # models.Department.objects.create(name='人事部')
#     #2.删除数据
#     # models.Model.objects.filter(id=1).delete()
#     # models.Model.objects.all().delete()
#
#     #3.获取数据(QuerySet类型)
#     # data_list = models.Model.objects.all()
#     # for obj in data_list:
#     #     print(obj.id, obj.name, obj.size)
#
#     # data_list = models.Model.objects.filter(id=1)
#     # row_obj = models.Model.objects.filter(id=1).first() #能取到第一行数据
#
#     #4.修改数据
#     # models.Model.objects.all().update(size=25)
#     # models.Model.objects.filter(id=1).update(size=25)

def changeStep(request):
    try:
        buf = io.BytesIO()
        step_str = request.POST['step']
        date_str = request.POST['date']
        img_data = models.Dataset.objects.filter(date=date_str, type="data", step=step_str)
        img_pred = models.Dataset.objects.filter(date=date_str, type="pred", step=step_str)
        img_label = models.Dataset.objects.filter(date=date_str, type="label", step=step_str)
        if len(img_data) == 0:
            index = data_list.index(date_str)
            data_selected = data[index, :, :, :, :].unsqueeze(0).to('cuda:0')
            t = time.index(step_str)
            data_ = torch.tensor(data_selected).to('cuda:0')[:, t:t + 1, :, :, :].squeeze().detach().cpu().numpy()
            buf.seek(0)
            buf.truncate(0)
            # 添加原预报数据
            plt.imshow(data_, cmap='jet', vmin=230, vmax=310)
            plt.axis('off')
            plt.savefig(buf, format='svg', bbox_inches='tight', pad_inches=0)
            img_data = base64.b64encode(buf.getvalue())
            models.Dataset.objects.create(origin="CMA", date=datetime.strptime(date_str, '%Y-%m-%d'), step=time[t],
                                          type="data", img=img_data)
        elif len(img_label) == 0:
            index = data_list.index(date_str)
            label_selected = label[index, :, :, :, :].unsqueeze(0).to('cuda:0')
            t = time.index(step_str)
            label_ = torch.tensor(label_selected).to('cuda:0')[:, t:t + 1, :, :, :].squeeze().detach().cpu().numpy()
            buf.seek(0)
            buf.truncate(0)
            # 添加标签
            plt.imshow(label_, cmap='jet', vmin=230, vmax=310)
            plt.axis('off')
            plt.savefig(buf, format='svg', bbox_inches='tight', pad_inches=0)
            img_label = base64.b64encode(buf.getvalue())
            models.Dataset.objects.create(origin="CMA", date=datetime.strptime(date_str, '%Y-%m-%d'), step=time[t],
                                          type="label", img=img_label)
        elif len(img_pred) == 0:
            index = data_list.index(date_str)
            data_selected = data[index, :, :, :, :].unsqueeze(0).to('cuda:0')
            t = time.index(step_str)
            data_ = torch.tensor(data_selected).to('cuda:0')[:, t:t + 1, :, :, :]
            pred = model(data_, time[t:t + 1]).squeeze().detach().cpu().numpy()
            buf.seek(0)
            buf.truncate(0)
            # 添加订正结果
            plt.imshow(pred, cmap='jet', vmin=230, vmax=310)
            plt.axis('off')
            plt.savefig(buf, format='svg', bbox_inches='tight', pad_inches=0)
            img_pred = base64.b64encode(buf.getvalue())
            models.Dataset.objects.create(origin="CMA", date=datetime.strptime(date_str, '%Y-%m-%d'), step=time[t],
                                          type="pred", img=img_pred)

        img_data = models.Dataset.objects.filter(date=date_str, type="data", step=step_str).first().img
        img_pred = models.Dataset.objects.filter(date=date_str, type="pred", step=step_str).first().img
        img_label = models.Dataset.objects.filter(date=date_str, type="label", step=step_str).first().img

        return JsonResponse({'data': str(img_data), 'pred': str(img_pred), 'label': str(img_label)})
    except Exception as r:
        return JsonResponse({'error': str(r)})

def getResult(request):
    try:
        buf = io.BytesIO()
        date_str = request.POST['date']
        data_date = models.Dataset.objects.filter(date=date_str, type="data")
        data_date2 = models.Dataset.objects.filter(date=date_str, type="pred")
        data_date3 = models.Dataset.objects.filter(date=date_str, type="label")
        if not (len(data_date) == len(time) and len(data_date2) == len(time) and len(data_date3) == len(time)):
            data_date.delete()
            data_date2.delete()
            data_date3.delete()
            index = data_list.index(date_str)
            data_selected = data[index, :, :, :, :].unsqueeze(0).to('cuda:0')
            label_selected = label[index, :, :, :, :].unsqueeze(0).to('cuda:0')
            for t in range(7):
                data_ = torch.tensor(data_selected).to('cuda:0')[:, t:t + 1, :, :, :]
                label_ = torch.tensor(label_selected).to('cuda:0')[:, t:t + 1, :, :, :]
                pred = model(data_, time[t:t + 1]).squeeze().detach().cpu().numpy()
                data_ = data_.squeeze().detach().cpu().numpy()
                label_ = label_.squeeze().detach().cpu().numpy()
                buf.seek(0)
                buf.truncate(0)
                # 添加订正结果
                plt.imshow(pred, cmap='jet', vmin=230, vmax=310)
                plt.axis('off')
                plt.savefig(buf, format='svg', bbox_inches='tight', pad_inches=0)
                img_pred = base64.b64encode(buf.getvalue())
                models.Dataset.objects.create(origin="CMA", date=datetime.strptime(date_str, '%Y-%m-%d'), step=time[t],
                                              type="pred", img=img_pred)
                buf.seek(0)
                buf.truncate(0)
                # 添加原预报数据
                plt.imshow(data_, cmap='jet', vmin=230, vmax=310)
                plt.axis('off')
                plt.savefig(buf, format='svg', bbox_inches='tight', pad_inches=0)
                img_data = base64.b64encode(buf.getvalue())
                models.Dataset.objects.create(origin="CMA", date=datetime.strptime(date_str, '%Y-%m-%d'), step=time[t],
                                              type="data", img=img_data)
                buf.seek(0)
                buf.truncate(0)
                # 添加标签
                plt.imshow(label_, cmap='jet', vmin=230, vmax=310)
                plt.axis('off')
                plt.savefig(buf, format='svg', bbox_inches='tight', pad_inches=0)
                img_label = base64.b64encode(buf.getvalue())
                models.Dataset.objects.create(origin="CMA", date=datetime.strptime(date_str, '%Y-%m-%d'), step=time[t],
                                              type="label", img=img_label)

        img_data = models.Dataset.objects.filter(date=date_str, step="0-24", type="data").first().img
        img_pred = models.Dataset.objects.filter(date=date_str, step="0-24", type="pred").first().img
        img_label = models.Dataset.objects.filter(date=date_str, step="0-24", type="label").first().img

        return JsonResponse({'data': str(img_data), 'pred': str(img_pred), 'label': str(img_label)})

    except Exception as r:
        return JsonResponse({'error': str(r)})

def download(request):
    file_path = "D:\\可视化系统\\后端 Django\\correction\\correct\\utils\\files\\NCCA 2024推荐-P00077-基于U-Net改进的日平均2m气温订正方法.pdf"
    if os.path.exists(file_path):
        with open(file_path, 'rb') as fh:
            response = HttpResponse(fh.read(), content_type="application/pdf")
            response['Content-Disposition'] = f'attachment; filename={os.path.basename(file_path)}'
            return response
    else:
        # 如果文件不存在，返回 404 错误
        return HttpResponse(status=404)