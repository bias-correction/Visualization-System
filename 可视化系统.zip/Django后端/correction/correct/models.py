# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey and OneToOneField has `on_delete` set to the desired behavior
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models

class Dataset(models.Model):
    origin = models.CharField(max_length=255, blank=True, null=True)
    date = models.DateField(blank=True, null=True)
    step_choices = (
            ('1', '0-24'),
            ('2', '24-48'),
            ('3', '48-72'),
            ('4', '72-96'),
            ('5', '96-120'),
            ('6', '120-144'),
            ('7', '144-168')
        )
    step = models.CharField(max_length=7, choices=step_choices, blank=True, null=True)
    type_choices = (
        ('1', 'data'),
        ('2', 'pred'),
        ('3', 'label')
    )
    type = models.CharField(max_length=5, choices=type_choices, blank=True, null=True)
    img = models.BinaryField(blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'dataset'

# class User(models.Model):
#     id = models.BigAutoField(primary_key=True)
#     username = models.CharField(max_length=255, blank=True, null=True)
#     phone = models.CharField(max_length=11, blank=True, null=True)
#     password = models.CharField(max_length=255, blank=True, null=True)
#     sex = models.CharField(max_length=1, blank=True, null=True)
#     education = models.CharField(max_length=5, blank=True, null=True)
#     address = models.TextField(blank=True, null=True)
#
#     class Meta:
#         managed = True
#         db_table = 'user'
