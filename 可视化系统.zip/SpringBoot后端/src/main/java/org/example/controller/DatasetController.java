package org.example.controller;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.example.bean.Dataset;
import org.example.bean.User;
import org.example.mapper.DatasetMapper;
import org.example.service.DatasetService;
import org.example.service.Impl.DatasetServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@RestController
public class DatasetController {
    @Autowired
    private DatasetService datasetService;
    @Autowired
    private DatasetMapper datasetMapper;
    @Autowired
    private BaseMapper<Dataset> baseMapper;
    @Autowired
    private DatasetServiceImpl datasetServiceImpl;

    @PostMapping("/getDatasetCount")
    public int getDatasetCount(@RequestParam Map<String, String> formData){
        String origin = formData.get("origin");
        String date = formData.get("date");
        String step = formData.get("step");
        String type = formData.get("type");

        LambdaQueryWrapper<Dataset> queryWrapper = datasetServiceImpl.getWrapper(origin, date, step, type);

        int count = (int) this.datasetService.count(queryWrapper);
        return count;
    }

    @PostMapping("/getDataset")
    public List<Dataset> getDataset(@RequestParam Map<String, String> formData){
        String origin = formData.get("origin");
        String date = formData.get("date");
        String step = formData.get("step");
        String type = formData.get("type");
        int order = Integer.parseInt(formData.get("pageOrder"));
        int size = Integer.parseInt(formData.get("pageSize"));

        LambdaQueryWrapper<Dataset> queryWrapper = datasetServiceImpl.getWrapper(origin, date, step, type);

        Page<Dataset> page = new Page<>(order, size);
        IPage<Dataset> result = datasetMapper.selectPage(page, queryWrapper);

        return result.getRecords();
    }

    @PostMapping("/updateDataset")
    public List<Dataset> updateDataset(@RequestParam Map<String, String> dataForm){
        try{
            int id = Integer.parseInt(dataForm.get("id"));
            String origin = dataForm.get("origin");
            String date = dataForm.get("date");
            String step = dataForm.get("step");
            String type = dataForm.get("type");

            LambdaUpdateWrapper<Dataset> updateWrapper = new LambdaUpdateWrapper<>();
            updateWrapper.eq(Dataset::getId, id)
                    .set(Dataset::getOrigin, origin)
                    .set(Dataset::getDate, date)
                    .set(Dataset::getStep, step)
                    .set(Dataset::getType, type);
            datasetMapper.update(null, updateWrapper);

            int order = Integer.parseInt(dataForm.get("pageOrder"));
            int size = Integer.parseInt(dataForm.get("pageSize"));
            String origin2 = dataForm.get("origin2");
            String date2 = dataForm.get("date2");
            String step2 = dataForm.get("step2");
            String type2 = dataForm.get("type2");

            LambdaQueryWrapper<Dataset> queryWrapper = datasetServiceImpl.getWrapper(origin2, date2, step2, type2);
            Page<Dataset> page = new Page<Dataset>(order, size);
            IPage<Dataset> result = datasetMapper.selectPage(page, queryWrapper);

            return result.getRecords();
        } catch (Exception e) {
            return null;
        }
    }

    @PostMapping("/deleteDataset")
    public List<Dataset> deleteDataset(@RequestParam Map<String, String> dataForm){
        try{
            int id = Integer.parseInt(dataForm.get("id"));

            datasetService.removeById(id);

            String origin = dataForm.get("origin");
            String date = dataForm.get("date");
            String step = dataForm.get("step");
            String type = dataForm.get("type");
            int order = Integer.parseInt(dataForm.get("pageOrder"));
            int size = Integer.parseInt(dataForm.get("pageSize"));
            Map<String, String> new_dataForm = new HashMap<>();
            new_dataForm.put("origin", origin);
            new_dataForm.put("date", date);
            new_dataForm.put("step", step);
            new_dataForm.put("type", type);
            int n = this.getDatasetCount(new_dataForm);
            if (order > Math.ceil((float)n / size)){
                order -= 1;
            }

            LambdaQueryWrapper<Dataset> queryWrapper = datasetServiceImpl.getWrapper(origin, date, step, type);
            Page<Dataset> page = new Page<Dataset>(order, size);
            IPage<Dataset> result = datasetMapper.selectPage(page, queryWrapper);

            return result.getRecords();
        } catch (Exception e) {
            return null;
        }
    }
}
