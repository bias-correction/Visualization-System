<template>
  <div id="app">
    <h1 class="title" style="font-family:'楷体'">管理员登录</h1>
    <div id="login">
      <el-form
      ref="ruleFormRef"
      :model="ruleForm"
      style="max-width: 350px;"
      label-width="auto"
      status-icon
      :rules="rules">
        <el-form-item label="联系方式" prop="phone">
          <el-input v-model="ruleForm.phone" placeholder="请输入联系方式" class="input" autocomplete="off" />
        </el-form-item>
        <el-form-item label="密码" prop="password">
          <el-input v-model="ruleForm.password" type="password" placeholder="请输入密码" class="input" autocomplete="off" />
        </el-form-item>
        <el-form-item label="手机验证码" prop="vali">
          <el-input v-model="ruleForm.vali" placeholder="请输入验证码" class="input2" autocomplete="off" />
          <el-button type="primary" id="get-vali" @click="send()" :disabled="is_count">获取验证码</el-button>
        </el-form-item>
        <el-form-item>
          <el-button type="success" plain id="confirm" @click="confirm()">确认</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import type { FormRules, ElMessage } from 'element-plus'
import { sendCode, validate } from "@/api/api"
import router from '@/router'

let is_count = ref<boolean>(false)
let is_right = ref<boolean>(false)
let stop = ref<boolean>(false)

const ruleForm = reactive<any>({
  phone: '',
  password: '',
  vali: '',
})
const reg = /^1[3456789]\d{9}$/

const validatePhone = (rule: any, value: any, callback: any) => {
  if (value === '') {
    is_right.value = false
    callback(new Error('请输入联系方式'))
  } else if(!reg.test(value)){
    is_right.value = false
    callback(new Error('联系方式格式不对'))
  } else{
    is_right.value = true
    callback()
  }
}

const validatePass = (rule: any, value: any, callback: any) => {
  if (value === '') {
    callback(new Error('请输入密码'))
  } else {
    callback()
  }
}

const validateCode = (rule: any, value: any, callback: any) => {
  if (value === '') {
    callback(new Error('请输入验证码'))
  } else {
    callback()
  }
}

const rules = reactive<FormRules<typeof ruleForm>>({
  phone: [{ validator: validatePhone, trigger: 'blur' }],
  password: [{ validator: validatePass, trigger: 'blur' }],
  vali: [{ validator: validateCode, trigger: 'blur' }],
})

//发送验证码
async function send(){
  if (is_right.value === true){
    stop.value = false
    await sendCode(ruleForm.phone).then((response: any)=>{
      if (response.data == true){
          let second = 120
          document.getElementById('get-vali').innerText = second + 's'
          is_count.value = true
          ElMessage({
            message: '获取请求已发送',
            type: 'success',
          })
          let countdown = setInterval(()=>{
          if (second == 0 || stop.value == true){
              clearInterval(countdown)
              document.getElementById('get-vali').innerText = '获取验证码'
              is_count.value = false
              return
          }
          second -= 1
          document.getElementById('get-vali').innerText = second + 's'
          }, 1000)
      } else if (response.data == false){
        ElMessage.error('获取请求失败')
      }
    })
  }else{
    ElMessage.error('请填写正确的联系方式')
  }
}
//确认登录
async function confirm(){
  if (ruleForm.phone != '' && ruleForm.password != '' && ruleForm.vali != ''){
    const formData = new FormData()
    formData.append("phone", ruleForm.phone)
    formData.append("password", ruleForm.password)
    formData.append("code", ruleForm.vali)
    await validate(formData).then((response: any)=>{
      if (response.data !== ''){
        stop.value = true
        ElMessage.success('登录成功')
        localStorage.setItem("userName", response.data)
        router.push({ path: '/data_manage/user' })
      } else {
        ElMessage.error('填写信息有误')
      }
    })
  } else {
    ElMessage.error('填写信息不完整')
  }
}
onMounted(()=>{
  document.getElementById('get-vali').innerText = '获取验证码'
})
</script>

<style>
body{
    background: url('../assets/img/background.jpg');
    background-repeat: no-repeat;
    background-size:120em 70em;
}
#app{
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 50px;
}  
.title{
    color:white;
    font-size: 40px;
}
#login{
    width: 450px;
    height: 220px;
    background-color: lightblue;
    border-radius: 5%;
    margin:100px auto 0 auto;
    padding-top: 50px;
    box-shadow: 0px 0px 20px white;
}
.el-form{
  margin:auto;
}
.input{
  width: 240px;
}
.input2{
  width: 130px;
}
#get-vali{
  margin-left: 10px;
  font-size: 12px;
  width: 80px;
}
#confirm{
  margin:15px auto 0 auto;
  font-size: 12px;
  width: 80px;
}
</style>