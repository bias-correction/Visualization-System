package org.example.service;

import com.baomidou.mybatisplus.extension.service.IService;
import org.example.bean.Dataset;

public interface DatasetService extends IService<Dataset> {
}
