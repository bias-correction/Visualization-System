<template>
  <div id="manage">
    <h5 id="login-name">{{ loginName }}管理员，欢迎登录！</h5>
    <el-container>
      <el-aside width="250px">
        <el-menu
        unique-opened
        router
        :default-active="$route.path">
        <el-sub-menu index="1">
            <template #title>
                <el-icon><component :is="home"></component></el-icon>
                <span>表格</span>
            </template>
            <el-menu-item v-for="path in paths" :key="path.path" :index='`/${path.path}`'>
                <el-icon><component :is="path.icon"></component></el-icon>
                {{ path.table_name }}
            </el-menu-item>
        </el-sub-menu>
    </el-menu>
    </el-aside>
  <el-main>
  <router-view v-slot="{ Component }">
    <keep-alive>
      <component :is="Component" />
    </keep-alive>
  </router-view>
  </el-main>
  </el-container>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive } from 'vue';
import {HomeFilled, Files} from '@element-plus/icons-vue'

const home = ref(HomeFilled)
const file = ref(Files)

const loginName = localStorage.getItem("userName")
const paths = reactive([
  {
    path: 'data_manage/user',
    table_name: '用户表',
    icon: file
  },
  {
    path: 'data_manage/dataset',
    table_name: '初始数据集表',
    icon: file
  }
])
</script>

<style>
body{
    background: url('../assets/img/background.jpg');
    background-repeat: no-repeat;
    background-size:120em 70em;
}
#login-name{
    color: white;
    font-size: 15px;
    margin-top: 10px;
    margin-bottom: 10px;
    padding-right: 20px;
    text-align: right;
}
#app{
  margin-top: 30px;
}
.el-container{
  margin: auto;
  width: calc(100%-50px);
}
.el-aside {
  background-color: #D3DCE6;
  color: #333;
  height: 750px;
  line-height: 500px;
}
.el-main {
    background-color: #E9EEF3;
    color: #333;
    height: 750px;
    padding-top: 0px;
}
</style>