<template>
  <h5 id="sel-table">{{ sel_table }}</h5>
</template>

<script setup lang="ts">
import {Store} from "@/store/index"

const store: any = Store()
const sel_table = store.selected_table
</script>

<style>
#sel-table{
    color:black;
    font-size: 15px;
    margin-top: 20px;
    margin-bottom: 10px;
}
</style>