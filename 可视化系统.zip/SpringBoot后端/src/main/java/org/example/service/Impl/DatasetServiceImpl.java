package org.example.service.Impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.example.bean.Dataset;
import org.example.mapper.DatasetMapper;
import org.example.service.DatasetService;
import org.springframework.stereotype.Service;

import java.util.Objects;

@Service
public class DatasetServiceImpl extends ServiceImpl<DatasetMapper, Dataset> implements DatasetService {
    public LambdaQueryWrapper<Dataset> getWrapper(String origin, String date, String step, String type){
        LambdaQueryWrapper<Dataset> queryWrapper = new LambdaQueryWrapper<>();
        if(!Objects.equals(origin, ""))
            queryWrapper.eq(Dataset::getOrigin, origin);
        if(!Objects.equals(date, ""))
            queryWrapper.eq(Dataset::getDate, date);
        if(!Objects.equals(step, ""))
            queryWrapper.eq(Dataset::getStep, step);
        if(!Objects.equals(type, ""))
            queryWrapper.eq(Dataset::getType, type);

        return queryWrapper;
    }
}
