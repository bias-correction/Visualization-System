import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import path from 'path'
import AutoImport from 'unplugin-auto-import/vite'
import Components from 'unplugin-vue-components/vite'
import { ElementPlusResolver } from 'unplugin-vue-components/resolvers'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [vue(),
    AutoImport({
      resolvers: [ElementPlusResolver()],
    }),
    Components({
      resolvers: [ElementPlusResolver()],
    }),
  ],  // 注册插件
  server: {
    host: '127.0.0.1',
    port: 8080,
    open:true,
    // proxy: {
    //   "/": {
    //       target: "http://127.0.0.1:8000",
    //       changeOrigin: true,
    //   }
    // }
  },
  resolve: {
    alias: {
      // 如果报错__dirname找不到，需要安装node,执行npm install @types/node
      "@": path.resolve(__dirname, "src"),
    }
  }
})