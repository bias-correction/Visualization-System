<template>
  <div>
    <div class="head">
        <router-link to="/correct_show">订正展示</router-link>
        <router-link to="/introduction">模型介绍</router-link>
        <router-link to="/pingjia">模型对比</router-link>
        <router-link to="/login" target="_blank" id="login">管理员登录</router-link>
    </div>
    <keep-alive>
        <router-view></router-view>
    </keep-alive>
  </div>
</template>

<script lang="ts" setup>
function to_login(){

}
</script>

<style scoped>
.head{
    width: 100%;
    height: 50px;
    line-height: 50px;
    background:rgba(10,50,220,0.08);
    text-align: left;
}
.head a{
    margin-left: 30px;
    text-decoration: none;
}
#login{
  float: right;
  margin-right: 10px;
}
</style>