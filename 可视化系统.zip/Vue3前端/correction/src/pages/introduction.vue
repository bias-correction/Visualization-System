<template>
    <div>
        <span style="font-family: '宋体';font-size: 20px;">本系统运用深度学习方法对2m气温进行订正，所使用的深度学习模型是S-CUnet 3+，模型详情可点击下面的“下载论文”按钮即可查看。</span>
        <br/>
        <el-button type="primary" @click="downloadFile">下载论文</el-button>
    </div>
</template>

<script lang="ts" setup>
import { download } from '@/api/api'
import { ElMessage } from 'element-plus'

async function downloadFile() {
    try {
        const response = await download()

        // 创建一个链接并触发下载
        const url = window.URL.createObjectURL(new Blob([response.data], { type: 'application/pdf' }));
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', 'S-CUnet 3+论文'); // 指定下载文件名
        document.body.appendChild(link);
        link.click();

        // 清理 URL 对象和链接
        window.URL.revokeObjectURL(url);
        document.body.removeChild(link);
      } catch (error) {
        ElMessage.error('下载文件失败')
      }
}
</script>

<style scoped>
div{
    width: 100%;
    margin-top: 20px;
}
.el-button{
    margin-top: 20px;
}
</style>