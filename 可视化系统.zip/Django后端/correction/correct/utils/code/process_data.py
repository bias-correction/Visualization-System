import torch
from torch.utils.data import Dataset, DataLoader
import netCDF4

class image_dataset():
    def __init__(self, origin, sort):
        data_dict = {}
        if origin == 'CMA':
            data_dict = {'train': [0, 1995], 'validate': [1995, 2099], 'test': [2099, 2202]}
        elif origin == 'ECMWF':
            data_dict = {'train': [0, 730], 'validate': [730, 834], 'test': [834, 1066]}
        self.data = torch.from_numpy(netCDF4.Dataset(origin+".nc")['data'][data_dict[sort][0]:data_dict[sort][1], :, 0, :, :]).unsqueeze(2)
        self.label = torch.from_numpy(netCDF4.Dataset(origin + ".nc")['data'][data_dict[sort][0]:data_dict[sort][1], :, 2, :, :]).unsqueeze(2)

    def __len__(self):
        return self.data.shape[0]

    def __getitem__(self, item):
        self.data_sample = self.data[item].float()
        self.label_sample = self.label[item].float()

        return self.data_sample, self.label_sample

if __name__ == '__main__':
    a = image_dataset('CMA', 'train')
    dataset = DataLoader(a, batch_size=20, shuffle=True, drop_last=False)
    for i, batch in enumerate(dataset):
        data, label = batch
        data = torch.tensor(data)
        label = torch.tensor(label)
        print(data.shape,label.shape)