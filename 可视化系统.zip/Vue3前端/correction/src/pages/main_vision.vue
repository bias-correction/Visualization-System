<template>
  <div id="app">
    <h1 class="title" style="font-family:'楷体'">2m气温订正演示系统</h1>
    <el-container>
    <el-aside width="250px">
      <guard />
    </el-aside>
    <el-main>
      <show />
    </el-main>
  </el-container>
  </div>
</template>

<script lang="ts" setup>
import guard from '@/components/guard.vue'
import show from '@/components/show.vue'

</script>

<style scoped>
#app{
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 50px;
}  
.title{
    color:white;
    font-size: 40px;
}
.el-container{
    margin: auto;
    width: 100%;
  }
.el-aside {
  background-color: #D3DCE6;
  color: #333;
  height: 680px;
  line-height: 500px;
}
.el-main {
  background-color: #E9EEF3;
  color: #333;
  height: 680px;
}
</style>
