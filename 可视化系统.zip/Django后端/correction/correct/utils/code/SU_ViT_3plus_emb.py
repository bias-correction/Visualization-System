import torch
from torch import nn
import numpy as np
from .SU_ViT_3plus import SU_ViT_3plus

def gen_mask(hw, n):
    window_size = hw // n
    shift_size = window_size // 2
    img_mask = torch.zeros((1, hw, hw, 1)).to('cuda')
    h_slices = (slice(0, -window_size),
                slice(-window_size, -shift_size),
                slice(-shift_size, None))
    w_slices = (slice(0, -window_size),
                slice(-window_size, -shift_size),
                slice(-shift_size, None))
    cnt = 0
    for h in h_slices:
        for w in w_slices:
            img_mask[:, h, w, :] = cnt
            cnt += 1

    img_mask = img_mask.unflatten(1, (n, hw // n))
    img_mask = img_mask.unflatten(3, (n, hw // n))
    img_mask = img_mask.permute(0, 1, 3, 2, 4, 5).contiguous().view(-1, window_size, window_size, 1)
    img_mask = img_mask.view(-1, (hw // n) ** 2)
    img_mask = img_mask.unsqueeze(1) - img_mask.unsqueeze(2)
    img_mask = img_mask.masked_fill(img_mask != 0, float(-100.0)).masked_fill(img_mask == 0, float(0.0))

    return img_mask


class Attention(nn.Module):
    def __init__(self, dim, hw, n):
        super(Attention, self).__init__()
        self.n = n
        self.hw = hw
        self.dim = dim
        self.scale = self.dim ** -0.5
        self.num_heads = 1
        self.window_size = [self.hw // self.n, self.hw // self.n]
        self.relative_positive_bias_table = nn.Parameter(
            torch.zeros((2 * (self.hw // self.n) - 1) * (2 * (self.hw // self.n) - 1), 1)
        )
        coords_h = torch.arange(self.hw // self.n)
        coords_w = torch.arange(self.hw // self.n)
        coords = torch.stack(torch.meshgrid([coords_h, coords_w]))
        coords_flatten = torch.flatten(coords, 1)
        relative_coords = coords_flatten[:, :, None] - coords_flatten[:, None, :]
        relative_coords = relative_coords.permute(1, 2, 0).contiguous()
        relative_coords[:, :, 0] += (self.hw // self.n) - 1
        relative_coords[:, :, 1] += (self.hw // self.n) - 1
        relative_coords[:, :, 0] *= 2 * (self.hw // self.n) - 1
        relative_position_index = relative_coords.sum(-1)
        self.register_buffer('relative_position_index', relative_position_index)

        self.qkv = nn.Linear(dim, dim * 3)
        nn.init.trunc_normal_(self.relative_positive_bias_table, std=.02)
        self.softmax = nn.Softmax(dim=-1)

    def forward(self, x, mask=None):
        B_, N, C = x.shape
        qkv = self.qkv(x).reshape(B_, N, 3, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4)
        q, k, v = qkv.unbind(0)

        q = q * self.scale
        attn = (q @ k.transpose(-2, -1))
        relative_position_bias = self.relative_positive_bias_table[self.relative_position_index.view(-1)].view(
            self.window_size[0] * self.window_size[1], self.window_size[0] * self.window_size[1], -1)
        relative_position_bias = relative_position_bias.permute(2, 0, 1).contiguous()
        attn = attn + relative_position_bias.unsqueeze(0)

        if mask is not None:
            num_window = mask.shape[0]
            attn = attn.view(B_ // num_window, num_window, self.num_heads, N, N) + mask.unsqueeze(1).unsqueeze(0)
            attn = attn.reshape(-1, self.num_heads, N, N)
            attn = self.softmax(attn)
        else:
            attn = self.softmax(attn)

        x = (attn @ v).transpose(1, 2).reshape(B_, N, C)

        return x


class Swin_ViT(nn.Module):
    def __init__(self, channels, hw, n, is_shift=False):
        super(Swin_ViT, self).__init__()
        self.n = n
        self.hw = hw
        self.is_shift = is_shift
        self.proj = nn.Sequential(nn.Unflatten(1, (self.n, self.hw // self.n)),
                                  nn.Unflatten(3, (self.n, self.hw // self.n)))
        self.attn = Attention(channels, hw, n)
        self.norm1 = nn.LayerNorm(channels)
        self.mlp = nn.Sequential(nn.Linear(channels, channels * 4),
                                 nn.GELU(),
                                 nn.Linear(channels * 4, channels))
        self.norm2 = nn.LayerNorm(channels)

    def forward(self, x):
        B, C, H, W = x.shape
        x = x.permute(0, 2, 3, 1)
        shortcut = x.flatten(1, 2)
        x = self.norm1(x)
        if self.is_shift == True:
            shift_size = self.hw // self.n // 2
            x = torch.roll(x, shifts=(-shift_size, -shift_size), dims=(1, 2))
            img_mask = gen_mask(self.hw, self.n)
        else:
            img_mask = None
        x = self.proj(x)
        x = x.permute(0, 1, 3, 2, 4, 5).flatten(1, 2).flatten(2, 3).flatten(0, 1)
        x = self.attn(x, img_mask)
        x = x.view(-1, self.hw // self.n, self.hw // self.n, C)
        x = x.view(B, self.n, self.n, self.hw // self.n, self.hw // self.n, C).permute(0, 1, 3, 2, 4, 5).flatten(1,
                                                                                                                 2).flatten(
            2, 3)
        if self.is_shift == True:
            shift_size = self.hw // self.n // 2
            x = torch.roll(x, shifts=(shift_size, shift_size), dims=(1, 2))
        x = x.view(B, H * W, C)
        x = shortcut + x
        x = x + self.mlp(self.norm2(x))
        x = x.view(B, H, W, C).permute(0, 3, 1, 2)

        return x

class SU_ViT_3plus_emb(nn.Module):
    def __init__(self):
        super(SU_ViT_3plus_emb, self).__init__()
        self.in_channels = 1
        self.en_channels = [64, 128, 256, 512]
        self.de_channels = [512, 256, 128, 64]
        self.en_hws = [64, 32, 16, 8]
        self.de_hws = [8, 16, 32, 64]
        self.default_steps = ['0-24', '24-48', '48-72', '72-96', '96-120', '120-144', '144-168']
        self.embed_dim = 64
        self.step_embed, self.step_map = self.create_step_embedding(self.embed_dim)
        self.SU_ViT_3plus = SU_ViT_3plus()
        self.SU_ViT_3plus.load_state_dict(
            torch.load('D:\\可视化系统\\后端 Django\\correction\\correct\\utils\\code\\batch_10_SU-ViT-3+_epoch_70_gamma_0.98_Smooth_best_1.pth'))
        for param in self.SU_ViT_3plus.parameters():
            param.requires_grad = False

        self.SU_ViT_3plus.en_vit1 = nn.Sequential(Swin_ViT(self.en_channels[0], self.en_hws[0], 2, False),
                                     Swin_ViT(self.en_channels[0], self.en_hws[0], 2, True))
        self.SU_ViT_3plus.en_vit2 = nn.Sequential(Swin_ViT(self.en_channels[1], self.en_hws[1], 2, False),
                                     Swin_ViT(self.en_channels[1], self.en_hws[1], 2, True))
        self.SU_ViT_3plus.en_vit3 = nn.Sequential(Swin_ViT(self.en_channels[2], self.en_hws[2], 2, False),
                                     Swin_ViT(self.en_channels[2], self.en_hws[2], 2, True))
        self.SU_ViT_3plus.en_vit4 = nn.Sequential(Swin_ViT(self.en_channels[3], self.en_hws[3], 2, False),
                                     Swin_ViT(self.en_channels[3], self.en_hws[3], 2, True))
        
        self.SU_ViT_3plus.de_vit3 = nn.Sequential(Swin_ViT(self.de_channels[1] * 4, self.de_hws[1], 2, False),
                                     Swin_ViT(self.de_channels[1] * 4, self.de_hws[1], 2, True))
        self.SU_ViT_3plus.de_vit2 = nn.Sequential(Swin_ViT(self.de_channels[2] * 4, self.de_hws[2], 2, False),
                                     Swin_ViT(self.de_channels[2] * 4, self.de_hws[2], 2, True))
        self.SU_ViT_3plus.de_vit1 = nn.Sequential(Swin_ViT(self.de_channels[3] * 4, self.de_hws[3], 2, False),
                                     Swin_ViT(self.de_channels[3] * 4, self.de_hws[3], 2, True))

    def create_step_embedding(self, dim):
        step_embed = nn.Parameter(torch.zeros(1, len(self.default_steps), 1, dim), requires_grad=True)
        step_map = {}
        idx = 0
        for step in self.default_steps:
            step_map[step] = idx
            idx += 1
        return step_embed, step_map

    def get_step_ids(self, steps, device):
        ids = np.array([self.step_map[step] for step in steps])
        return torch.from_numpy(ids).to(device)

    def get_step_emb(self, step_emb, steps):
        ids = self.get_step_ids(steps, step_emb.device).type(torch.long)
        return step_emb[:, ids, :, :]

    def forward(self, x, lead_times: list):
        B, T, C, H, W = x.shape
        assert T == len(lead_times), "the length of step list must be equal to T"
        step_embedding = self.get_step_emb(self.step_embed, lead_times)
        x = x.flatten(0, 1)
        x = self.SU_ViT_3plus.conv0(x)
        x = x.unflatten(0, (B, T))
        x = x.permute(0, 1, 3, 4, 2).flatten(2, 3)
        x = x + step_embedding
        x = x.unflatten(2, (H, W)).permute(0, 1, 4, 2, 3).flatten(0, 1)
        en_x1 = self.SU_ViT_3plus.en_vit1(x)
        en_x2 = self.SU_ViT_3plus.en_vit2(self.SU_ViT_3plus.en_pool1(en_x1))
        en_x3 = self.SU_ViT_3plus.en_vit3(self.SU_ViT_3plus.en_pool2(en_x2))
        en_x4 = self.SU_ViT_3plus.en_vit4(self.SU_ViT_3plus.en_pool3(en_x3))

        de_x1_3 = self.SU_ViT_3plus.de_pool1_3(en_x1)
        de_x2_3 = self.SU_ViT_3plus.de_pool2_3(en_x2)
        de_x3_3 = self.SU_ViT_3plus.de_conv3_3(en_x3)
        de_x4_3 = self.SU_ViT_3plus.de_up4_3(en_x4)
        de_x3 = self.SU_ViT_3plus.de_vit3(torch.cat([de_x1_3, de_x2_3, de_x3_3, de_x4_3], dim=1))

        de_x1_2 = self.SU_ViT_3plus.de_pool1_2(en_x1)
        de_x2_2 = self.SU_ViT_3plus.de_conv2_2(en_x2)
        de_x3_2 = self.SU_ViT_3plus.de_up3_2(de_x3)
        de_x4_2 = self.SU_ViT_3plus.de_up4_2(en_x4)
        de_x2 = self.SU_ViT_3plus.de_vit2(torch.cat([de_x1_2, de_x2_2, de_x3_2, de_x4_2], dim=1))

        de_x1_1 = self.SU_ViT_3plus.de_conv1_1(en_x1)
        de_x2_1 = self.SU_ViT_3plus.de_up2_1(de_x2)
        de_x3_1 = self.SU_ViT_3plus.de_up3_1(de_x3)
        de_x4_1 = self.SU_ViT_3plus.de_up4_1(en_x4)
        de_x1 = self.SU_ViT_3plus.de_vit1(torch.cat([de_x1_1, de_x2_1, de_x3_1, de_x4_1], dim=1))
        
        output = self.SU_ViT_3plus.conv_f(de_x1)
        output = output.reshape(B, T, C, H, W)
        
        return output