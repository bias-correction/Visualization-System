<template>
    <div class="month">
        <el-date-picker
            v-model="value2"
            type="date"
            placeholder="选择年月"
            :disabled-date="pickerOptions"
            :default-value="defaultTime()"
            @change="get_info3()">
        </el-date-picker>
    </div>
    <div class="submit">
        <el-button type="primary" plain @click="submit" :disabled="confirm_dis">确定查找</el-button>
    </div>
    <div class="choice-show">
        <span>年月份：{{ date_c }}</span>
    </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed } from 'vue'
import {Store} from "@/store/index"
import { ElNotification } from 'element-plus'
import { getResult } from '@/api/api'
import pubsub from 'pubsub-js'

const store: any = Store()
let value2 = ref<string>('')
let date_c = ref<string>('无')
let mons = reactive<string[]>(['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'])
let confirm_dis = computed(()=>{
    return store.disabled
})
const defaultTime = () => {
    var now = new Date();
    now.setFullYear(2022);
    now.setMonth(0);
    return now
}
function pickerOptions(value:Date) {
    if (value.getFullYear() === 2022){
        switch(value.getMonth()){
            case 0:
                return !(value.getDate() == 3 || value.getDate() == 6 || value.getDate() == 10 || value.getDate() == 13 || value.getDate() == 17 || 
                value.getDate() == 20 || value.getDate() == 24 || value.getDate() == 27 || value.getDate() == 31);
            case 1:
                return !(value.getDate() == 3 || value.getDate() == 7 || value.getDate() == 10 || value.getDate() == 14 || value.getDate() == 17 || 
                value.getDate() == 21 || value.getDate() == 24 || value.getDate() == 28);
            case 2:
                return !(value.getDate() == 3 || value.getDate() == 7 || value.getDate() == 10 || value.getDate() == 14 || value.getDate() == 17 || 
                value.getDate() == 21 || value.getDate() == 24 || value.getDate() == 28 || value.getDate() == 31);
            case 3:
                return !(value.getDate() == 4 || value.getDate() == 7 || value.getDate() == 11 || value.getDate() == 14 || value.getDate() == 18 || 
                value.getDate() == 21 || value.getDate() == 25 || value.getDate() == 28);
            case 4:
                return !(value.getDate() == 2 || value.getDate() == 5 || value.getDate() == 9 || value.getDate() == 12 || value.getDate() == 16 || 
                value.getDate() == 19 || value.getDate() == 23 || value.getDate() == 26 || value.getDate() == 30);
            case 5:
                return !(value.getDate() == 2 || value.getDate() == 6 || value.getDate() == 9 || value.getDate() == 13 || value.getDate() == 16 || 
                value.getDate() == 20 || value.getDate() == 23 || value.getDate() == 27 || value.getDate() == 30);
            case 6:
                return !(value.getDate() == 4 || value.getDate() == 7 || value.getDate() == 11 || value.getDate() == 14 || value.getDate() == 18 || 
                value.getDate() == 21 || value.getDate() == 25 || value.getDate() == 28);
            case 7:
                return !(value.getDate() == 1 || value.getDate() == 4 || value.getDate() == 8 || value.getDate() == 11 || value.getDate() == 15 || 
                value.getDate() == 18 || value.getDate() == 22 || value.getDate() == 25 || value.getDate() == 29);
            case 8:
                return !(value.getDate() == 1 || value.getDate() == 5 || value.getDate() == 8 || value.getDate() == 12 || value.getDate() == 15 || 
                value.getDate() == 19 || value.getDate() == 22 || value.getDate() == 26 || value.getDate() == 29);
            case 9:
                return !(value.getDate() == 3 || value.getDate() == 6 || value.getDate() == 10 || value.getDate() == 13 || value.getDate() == 17 || 
                value.getDate() == 20 || value.getDate() == 24 || value.getDate() == 27 || value.getDate() == 31);
            case 10:
                return !(value.getDate() == 3 || value.getDate() == 7 || value.getDate() == 10 || value.getDate() == 14 || value.getDate() == 17 || 
                value.getDate() == 21 || value.getDate() == 24 || value.getDate() == 28);
            case 11:
                return !(value.getDate() == 1 || value.getDate() == 5 || value.getDate() == 8 || value.getDate() == 12 || value.getDate() == 15 || 
                value.getDate() == 19 || value.getDate() == 22 || value.getDate() == 26 || value.getDate() == 29);
        }
    } else {
        return true;
    }
}
function get_info3(){
    if (value2.value==null || value2.value==undefined){
        value2.value = ''
        date_c.value = '无'
    }
    else{
        let mon = value2.value.toString().split(' ')[1]
        let day = parseInt(value2.value.toString().split(' ')[2])
        date_c.value = value2.value.toString().split(' ')[3]+'-'+(mons.indexOf(mon)+1).toString()+'-'+day.toString()
    }
}
async function submit(){
    if (date_c.value == '无'){
        ElNotification.error({
            title: '查询错误',
            message: '请把查询信息填写或选择完整'
        })
    } else {
        const formData = new FormData()
        formData.append("date", date_c.value)
        store.is_loading = true
        store.disabled = true
        await getResult(formData).then((response: any)=>{
            if (response.data.error){
                ElNotification.error({
                    title: '查询错误',
                    message: response.data.error
                })
            }
            else{
                console.log(response.data.data)
                store.getImg([
                    date_c.value,
                    '0-24',
                    `data:image/svg+xml;base64,${response.data.data.split('\'')[1]}`,
                    `data:image/svg+xml;base64,${response.data.pred.split('\'')[1]}`,
                    `data:image/svg+xml;base64,${response.data.label.split('\'')[1]}`
                ])
            } 
        })
        store.disabled = false
        store.is_loading = false
        pubsub.publish('getStep', store.step)
    }
}
</script>

<style scoped>
.month{
    height: 60px;
    line-height: 60px;
    background-image: linear-gradient(to top, white, blue);
}
.submit{
    height: 60px;
    line-height: 60px;
}
.choice-show{
    width: 200px;
    height: 60px;
    margin-left: 25px;
    line-height: 60px;
}
.choice-show span{
    font-size: 10px;
}
</style>