package org.example.service;

import com.baomidou.mybatisplus.extension.service.IService;
import org.example.bean.User;

public interface UserService extends IService<User> {
}
