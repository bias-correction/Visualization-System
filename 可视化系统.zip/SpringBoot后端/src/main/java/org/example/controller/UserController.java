package org.example.controller;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zhenzi.sms.ZhenziSmsClient;
import org.example.bean.User;
import org.example.mapper.UserMapper;
import org.example.service.Impl.RedisUtils;
import org.example.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.concurrent.TimeUnit;


@RestController
public class UserController {
    @Autowired
    private UserService userService;
    @Autowired
    private BaseMapper<User> baseMapper;
    @Autowired
    private UserMapper userMapper;
    @Autowired
    RedisUtils redisUtils;
    private String apiUrl = "https://sms_developer.zhenzikj.com";//调用的接口
    private String appId = "113952";
    private String appSecret = "e3c58795-4aeb-492b-b7ea-e09f8c4421f1";
    @GetMapping("/code")
    public boolean getCode(@RequestParam("memPhone") String phone) throws Exception {
        try{
            JSONObject json = null;
            String code = String.valueOf(new Random().nextInt(899999) + 100000);
            ZhenziSmsClient client = new ZhenziSmsClient(apiUrl, appId, appSecret);
            Map<String, Object> params = new HashMap<String, Object>();
            params.put("number", phone);
            params.put("templateId", "12993");
            String[] templateParams = new String[2];
            templateParams[0] = code;
            templateParams[1] = "2分钟";
            params.put("templateParams",templateParams);
            String result = client.send(params);
            json = JSONObject.parseObject(result);
            if (json.getIntValue("code")!=0){//发送短信失败
                return  false;
            }
            //将验证码存到redis中,同时存入创建时间（也可以传入session）
            //以json存放，这里使用的是阿里的fastjson
            json = new JSONObject();
            json.put("memPhone",phone);
            json.put("code",code);
            json.put("createTime",System.currentTimeMillis());
            // 将认证码存入redis，有效时长5分钟
            redisUtils.set("verifyCode"+phone, json,2L, TimeUnit.MINUTES);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @PostMapping("/validate")
    public String validate(@RequestParam Map<String, String> dataForm){
        String phone = dataForm.get("phone");
        String password = dataForm.get("password");
        String code = dataForm.get("code");
        JSONObject Vcode = (JSONObject)redisUtils.get("verifyCode"+phone);
        JSONObject verifyCode = (JSONObject)redisUtils.get("verifyCode"+phone);
        if(verifyCode.get("code").equals(code)) {
            LambdaQueryWrapper<User> queryWrapper = new LambdaQueryWrapper<>();
            queryWrapper.eq(User::getPhone, phone)
                    .eq(User::getPassword, password)
                    .select(User::getUsername);
            List<User> user = this.baseMapper.selectList(queryWrapper);

            return user.get(0).getUsername();
        }
        else{
            return "";
        }
    }

    @PostMapping("/getUserCount")
    public int getUserCount(@RequestParam Map<String, String> dataForm){
        String username = dataForm.get("username");
        String phone = dataForm.get("phone");
        String sex = dataForm.get("sex");
        String education = dataForm.get("education");
        String address = dataForm.get("address");

        LambdaQueryWrapper<User> queryWrapper = new LambdaQueryWrapper<>();
        if (!Objects.equals(username, ""))
            queryWrapper.like(User::getUsername, username);
        if (!Objects.equals(phone, ""))
            queryWrapper.like(User::getPhone, phone);
        if (!Objects.equals(sex, ""))
            queryWrapper.eq(User::getSex, sex);
        if (!Objects.equals(education, ""))
            queryWrapper.eq(User::getEducation, education);
        if (!Objects.equals(address, ""))
            queryWrapper.like(User::getAddress, address);
        int count = (int) this.userService.count(queryWrapper);

        return count;
    }

    @PostMapping("/getuser")
    public List<User> getUser(@RequestParam Map<String, String> dataForm){
        String username = dataForm.get("username");
        String phone = dataForm.get("phone");
        String sex = dataForm.get("sex");
        String education = dataForm.get("education");
        String address = dataForm.get("address");
        int order = Integer.parseInt(dataForm.get("pageOrder"));
        int size = Integer.parseInt(dataForm.get("pageSize"));
        LambdaQueryWrapper<User> queryWrapper = new LambdaQueryWrapper<>();
        if (!Objects.equals(username, ""))
            queryWrapper.like(User::getUsername, username);
        if (!Objects.equals(phone, ""))
            queryWrapper.like(User::getPhone, phone);
        if (!Objects.equals(sex, ""))
            queryWrapper.eq(User::getSex, sex);
        if (!Objects.equals(education, ""))
            queryWrapper.eq(User::getEducation, education);
        if (!Objects.equals(address, ""))
            queryWrapper.like(User::getAddress, address);

        Page<User> page = new Page<>(order, size);
        IPage<User> result = userMapper.selectPage(page, queryWrapper);

        return result.getRecords();
    }

    @PostMapping("/addUser")
    public List<User> addUser(@RequestParam Map<String, String> dataForm){
        try{
            String username = dataForm.get("username");
            String phone = dataForm.get("phone");
            String password = dataForm.get("password");
            String sex = dataForm.get("sex");
            String education = dataForm.get("education");
            String address = dataForm.get("address");
            int order = Integer.parseInt(dataForm.get("pageOrder"));
            int size = Integer.parseInt(dataForm.get("pageSize"));

            User user = new User();
            user.setUsername(username);
            user.setPhone(phone);
            user.setPassword(password);
            user.setSex(sex);
            user.setEducation(education);
            user.setAddress(address);
            userService.save(user);
            Page<User> page = new Page<User>(order, size);
            IPage<User> result = userMapper.selectPage(page, null);

            return result.getRecords();
        } catch (Exception e){
            return null;
        }
    }

    @PostMapping("/updateUser")
    public List<User> updateUser(@RequestParam Map<String, String> dataForm){
        try{
            int id = Integer.parseInt(dataForm.get("id"));
            String username = dataForm.get("username");
            String phone = dataForm.get("phone");
            String password = dataForm.get("password");
            String sex = dataForm.get("sex");
            String education = dataForm.get("education");
            String address = dataForm.get("address");

            LambdaUpdateWrapper<User> updateWrapper = new LambdaUpdateWrapper<>();
            updateWrapper.eq(User::getId, id)
                    .set(User::getUsername, username)
                    .set(User::getPhone, phone)
                    .set(User::getPassword, password)
                    .set(User::getSex, sex)
                    .set(User::getEducation, education)
                    .set(User::getAddress, address);
            userMapper.update(null, updateWrapper);

            int order = Integer.parseInt(dataForm.get("pageOrder"));
            int size = Integer.parseInt(dataForm.get("pageSize"));
            String username2 = dataForm.get("username2");
            String phone2 = dataForm.get("phone2");
            String sex2 = dataForm.get("sex2");
            String education2 = dataForm.get("education2");
            String address2 = dataForm.get("address2");

            LambdaQueryWrapper<User> queryWrapper = new LambdaQueryWrapper<>();
            if (!Objects.equals(username2, ""))
                queryWrapper.like(User::getUsername, username2);
            if (!Objects.equals(phone2, ""))
                queryWrapper.like(User::getPhone, phone2);
            if (!Objects.equals(sex2, ""))
                queryWrapper.eq(User::getSex, sex2);
            if (!Objects.equals(education2, ""))
                queryWrapper.eq(User::getEducation, education2);
            if (!Objects.equals(address2, ""))
                queryWrapper.like(User::getAddress, address2);
            Page<User> page = new Page<User>(order, size);
            IPage<User> result = userMapper.selectPage(page, queryWrapper);

            return result.getRecords();
        } catch (Exception e) {
            return null;
        }
    }

    @PostMapping("/deleteUser")
    public List<User> deleteUser(@RequestParam Map<String, String> dataForm){
        try{
            int id = Integer.parseInt(dataForm.get("id"));

            userService.removeById(id);

            String username = dataForm.get("username");
            String phone = dataForm.get("phone");
            String sex = dataForm.get("sex");
            String education = dataForm.get("education");
            String address = dataForm.get("address");
            int order = Integer.parseInt(dataForm.get("pageOrder"));
            int size = Integer.parseInt(dataForm.get("pageSize"));
            Map<String, String> new_dataForm = new HashMap<>();
            new_dataForm.put("username", username);
            new_dataForm.put("phone", phone);
            new_dataForm.put("sex", sex);
            new_dataForm.put("education", education);
            new_dataForm.put("address", address);
            int n = this.getUserCount(new_dataForm);
            if (order > Math.ceil((float)n / size)){
                order -= 1;
            }

            LambdaQueryWrapper<User> queryWrapper = new LambdaQueryWrapper<>();
            if (!Objects.equals(username, ""))
                queryWrapper.like(User::getUsername, username);
            if (!Objects.equals(phone, ""))
                queryWrapper.like(User::getPhone, phone);
            if (!Objects.equals(sex, ""))
                queryWrapper.eq(User::getSex, sex);
            if (!Objects.equals(education, ""))
                queryWrapper.eq(User::getEducation, education);
            if (!Objects.equals(address, ""))
                queryWrapper.like(User::getAddress, address);
            Page<User> page = new Page<User>(order, size);
            IPage<User> result = userMapper.selectPage(page, queryWrapper);

            return result.getRecords();
        } catch (Exception e) {
            return null;
        }
    }
}
